<?php
// created: 2016-03-01 13:25:46
$dictionary["HAT_Systems"]["fields"]["hat_systems_hat_asset_locations"] = array (
  'name' => 'hat_systems_hat_asset_locations',
  'type' => 'link',
  'relationship' => 'hat_systems_hat_asset_locations',
  'source' => 'non-db',
  'module' => 'HAT_Asset_Locations',
  'bean_name' => 'HAT_Asset_Locations',
  'vname' => 'LBL_HAT_SYSTEMS_HAT_ASSET_LOCATIONS_FROM_HAT_ASSET_LOCATIONS_TITLE',
);
