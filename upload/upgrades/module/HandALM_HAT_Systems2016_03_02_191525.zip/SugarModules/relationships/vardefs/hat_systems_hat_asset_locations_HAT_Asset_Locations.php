<?php
// created: 2016-03-01 13:25:46
$dictionary["HAT_Asset_Locations"]["fields"]["hat_systems_hat_asset_locations"] = array (
  'name' => 'hat_systems_hat_asset_locations',
  'type' => 'link',
  'relationship' => 'hat_systems_hat_asset_locations',
  'source' => 'non-db',
  'module' => 'HAT_Systems',
  'bean_name' => 'HAT_Systems',
  'vname' => 'LBL_HAT_SYSTEMS_HAT_ASSET_LOCATIONS_FROM_HAT_SYSTEMS_TITLE',
);
