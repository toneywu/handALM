<?php
// created: 2016-03-03 10:09:58
$dictionary["HAT_Assets"]["fields"]["ham_sr_hat_assets"] = array (
  'name' => 'ham_sr_hat_assets',
  'type' => 'link',
  'relationship' => 'ham_sr_hat_assets',
  'source' => 'non-db',
  'module' => 'HAM_SR',
  'bean_name' => 'HAM_SR',
  'side' => 'right',
  'vname' => 'LBL_HAM_SR_HAT_ASSETS_FROM_HAM_SR_TITLE',
);
