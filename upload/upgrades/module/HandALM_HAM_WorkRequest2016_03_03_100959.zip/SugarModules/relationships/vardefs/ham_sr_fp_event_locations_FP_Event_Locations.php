<?php
// created: 2016-03-03 10:09:58
$dictionary["FP_Event_Locations"]["fields"]["ham_sr_fp_event_locations"] = array (
  'name' => 'ham_sr_fp_event_locations',
  'type' => 'link',
  'relationship' => 'ham_sr_fp_event_locations',
  'source' => 'non-db',
  'module' => 'HAM_SR',
  'bean_name' => 'HAM_SR',
  'side' => 'right',
  'vname' => 'LBL_HAM_SR_FP_EVENT_LOCATIONS_FROM_HAM_SR_TITLE',
);
