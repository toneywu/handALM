                    Login Slider Images Plugin
                  ==============================


1. OVERVIEW

This plugin is used to set images in slider in sugar login page.

******************************************************************************

2. COMPONENTS

SugarCRM Login Slider works with the following software versions:

  - SugarCRM 6.*

*****************************************************************************

3. Installation :-- 

   Following steps you can use to install this plugin :-

          1) Login your sugarcrm and go to admin section.
          2) Click on 'Module Loader' section
          3) Upload and install sugar login slider zip file
          4) Repair and now you are ready to use this plugin.



****************************************************************************
4. DIRECTORY STRUCTURE

The installation process will create several subfolders under the main
installation directory Like:

1) :- custom/Extension/modules/Administration/Ext/Administration/loginPageSliderGallery.php
2) :- custom/Extension/modules/Administration/Ext/Language/en_us.loginPageSliderGallery.php
3) :- custom/Include/loginSlider ( New Folder In Include Directory)

   ---- Store images in custom/Include/loginSlider/images/slider folder after upload images from upload Image View.

4) :- custom/modules/Administration/controller.php
5) :- custom/modules/Administration/slider_function.php
6) :- custom/modules/Administration/views/view.loginpagesliderconfiguration.php
7) :- custom/modules/Administration/views/view.loginpageslidergallery.php
8) :- custom/modules/Users/Login.php

****************************************************************************

5. Work Flow

After install this folder, there is another section will be created called 'Login Page Image Slider' Section in admin view.

In this section there is two sub section :-

1)  Image Slider Configuration :--  This section is used to configure no of images which is displayed in sugarcrm login page.
                                    You can set how many images you want to display in your sugar login slider.
                                    After set this configuration now you have to go in new subsection called 'Upload images' which is describe below.

2)  Upload images :--  This section is used to upload images which is displayed in your login slider.

****************************************************************************

6. Impact On Your Existing Directory Structure :--

   After install this folder your current directory structure will effected.
   there is two files which is impact :--

   1) :-- custom/modules/Administration/controller.php

          :-- If your file exist in this path it will rename/overrite with controller_orig.php.
              After this your exist feature/action will not work. you have to copy or paste your feature/action in newly created controller.php.

   2) :-- custom/modules/Users/Login.php
          
          :-- same thing on this.

***************************************************************************

7. Impact After Uninstall :--

   After uninstall all newly folder/subfolder and files will be removed.
   And exixt files will be restore.
****************************************************************************
                        

                                    



