<?php

if (!defined('sugarEntry'))
    define('sugarEntry', true);
pre_execute();

function pre_execute()
{
    // backup existing files
    $file = 'custom/modules/Administration/controller.php';
    $newfile = 'custom/modules/Administration/controller_orig.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }

    $file = 'custom/modules/Users/Login.php';
    $newfile = 'custom/modules/Users/Login_orig.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }
}
