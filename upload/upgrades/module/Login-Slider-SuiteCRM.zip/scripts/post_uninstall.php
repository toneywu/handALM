<?php

if (!defined('sugarEntry'))
    define('sugarEntry', true);

post_uninstall();

function post_uninstall()
{
    global $db;

    // Remove slider configuration from sugar config table
    $db->query("Delete From config where category = 'image_slider_conf'");
    // End

    // restore the original files
    $file = 'custom/modules/Administration/controller_orig.php';
    $newfile = 'custom/modules/Administration/controller.php';

    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }

    // restore the original files
    $file = 'custom/modules/Users/Login_orig.php';
    $newfile = 'custom/modules/Users/Login.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }

    $files = array(
        'custom/Extension/modules/Administration/Ext/Administration/loginPageSliderGallery.php',
        'custom/Extension/modules/Administration/Ext/Language/en_us.loginPageSliderGallery.php',
        'custom/modules/Administration/views/view.loginpagesliderconfiguration.php',
        'custom/modules/Administration/views/view.loginpageslidergallery.php',
        'custom/modules/Administration/slider_function.php',
    );
    foreach ($files as $file) {
        if (file_exists($file)) {
            unlink($file);
        }
    }
    recursiveRemove("custom/include/loginSlider/");
}

function recursiveRemove($dir)
{
    $structure = glob(rtrim($dir, "/") . '/*');
    if (is_array($structure)) {
        foreach ($structure as $file) {
            if (is_dir($file))
                recursiveRemove($file);
            elseif (is_file($file))
                unlink($file);
        }
    }
    rmdir($dir);
}
