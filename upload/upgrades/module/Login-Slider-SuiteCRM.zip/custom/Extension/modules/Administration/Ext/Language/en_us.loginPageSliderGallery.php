<?php
$mod_strings['LBL_UPLOAD_IMAGE_FOR_LOGIN_SLIDER'] = 'Upload images';
$mod_strings['LBL_UPLOAD_IMAGE_FOR_LOGIN_SLIDER_DESCRITOPN'] = 'Upload images to be displayed on login page slider.';

$mod_strings['LBL_CONFIGURATION_FOR_LOGIN_IMAGE_SLIDER'] = 'Image Slider Configuration';
$mod_strings['LBL_CONFIGURATION_FOR_LOGIN_IMAGE_SLIDER_DESCRITOPN'] = 'Configure number of images to be displayed on login page slider.';
$mod_strings['LBL_UPLOAD_IMAGE_FOR_LOGIN_SLIDER_SECTION'] = 'Login Page Image Slider';
$mod_strings['LBL_UPLOAD_IMAGE_FOR_LOGIN_SLIDER_SECTION_DESCRIPTION'] = 'Configuration and image upload for login page image slider.';