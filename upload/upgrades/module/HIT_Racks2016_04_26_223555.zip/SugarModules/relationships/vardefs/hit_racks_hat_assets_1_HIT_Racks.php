<?php
// created: 2016-04-26 22:35:53
$dictionary["HIT_Racks"]["fields"]["hit_racks_hat_assets_1"] = array (
  'name' => 'hit_racks_hat_assets_1',
  'type' => 'link',
  'relationship' => 'hit_racks_hat_assets_1',
  'source' => 'non-db',
  'module' => 'HAT_Assets',
  'bean_name' => 'HAT_Assets',
  'side' => 'right',
  'vname' => 'LBL_HIT_RACKS_HAT_ASSETS_1_FROM_HAT_ASSETS_TITLE',
);
