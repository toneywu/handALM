<?php
// created: 2016-02-08 10:53:31
$dictionary["Contact"]["fields"]["hat_assets_contacts"] = array (
  'name' => 'hat_assets_contacts',
  'type' => 'link',
  'relationship' => 'hat_assets_contacts',
  'source' => 'non-db',
  'module' => 'HAT_Assets',
  'bean_name' => 'HAT_Assets',
  'side' => 'right',
  'vname' => 'LBL_HAT_ASSETS_CONTACTS_FROM_HAT_ASSETS_TITLE',
);
