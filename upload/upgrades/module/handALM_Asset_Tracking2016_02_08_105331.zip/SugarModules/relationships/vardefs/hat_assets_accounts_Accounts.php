<?php
// created: 2016-02-08 10:53:31
$dictionary["Account"]["fields"]["hat_assets_accounts"] = array (
  'name' => 'hat_assets_accounts',
  'type' => 'link',
  'relationship' => 'hat_assets_accounts',
  'source' => 'non-db',
  'module' => 'HAT_Assets',
  'bean_name' => 'HAT_Assets',
  'side' => 'right',
  'vname' => 'LBL_HAT_ASSETS_ACCOUNTS_FROM_HAT_ASSETS_TITLE',
);
