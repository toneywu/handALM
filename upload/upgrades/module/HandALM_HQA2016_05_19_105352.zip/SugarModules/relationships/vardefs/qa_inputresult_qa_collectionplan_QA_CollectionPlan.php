<?php
// created: 2016-05-19 10:53:50
$dictionary["QA_CollectionPlan"]["fields"]["qa_inputresult_qa_collectionplan"] = array (
  'name' => 'qa_inputresult_qa_collectionplan',
  'type' => 'link',
  'relationship' => 'qa_inputresult_qa_collectionplan',
  'source' => 'non-db',
  'module' => 'QA_inputresult',
  'bean_name' => 'QA_inputresult',
  'side' => 'right',
  'vname' => 'LBL_QA_INPUTRESULT_QA_COLLECTIONPLAN_FROM_QA_INPUTRESULT_TITLE',
);
