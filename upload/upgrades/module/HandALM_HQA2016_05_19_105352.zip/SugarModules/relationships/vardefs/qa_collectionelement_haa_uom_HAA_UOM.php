<?php
// created: 2016-05-19 10:53:39
$dictionary["HAA_UOM"]["fields"]["qa_collectionelement_haa_uom"] = array (
  'name' => 'qa_collectionelement_haa_uom',
  'type' => 'link',
  'relationship' => 'qa_collectionelement_haa_uom',
  'source' => 'non-db',
  'module' => 'QA_CollectionElement',
  'bean_name' => 'QA_CollectionElement',
  'side' => 'right',
  'vname' => 'LBL_QA_COLLECTIONELEMENT_HAA_UOM_FROM_QA_COLLECTIONELEMENT_TITLE',
);
