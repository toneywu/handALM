<?php
// created: 2016-05-19 10:53:43
$dictionary["HAA_UOM"]["fields"]["qa_collectionplan_haa_uom"] = array (
  'name' => 'qa_collectionplan_haa_uom',
  'type' => 'link',
  'relationship' => 'qa_collectionplan_haa_uom',
  'source' => 'non-db',
  'module' => 'QA_CollectionPlan',
  'bean_name' => 'QA_CollectionPlan',
  'side' => 'right',
  'vname' => 'LBL_QA_COLLECTIONPLAN_HAA_UOM_FROM_QA_COLLECTIONPLAN_TITLE',
);
