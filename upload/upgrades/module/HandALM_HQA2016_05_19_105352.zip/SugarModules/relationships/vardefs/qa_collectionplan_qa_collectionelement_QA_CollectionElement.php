<?php
// created: 2016-05-19 10:53:43
$dictionary["QA_CollectionElement"]["fields"]["qa_collectionplan_qa_collectionelement"] = array (
  'name' => 'qa_collectionplan_qa_collectionelement',
  'type' => 'link',
  'relationship' => 'qa_collectionplan_qa_collectionelement',
  'source' => 'non-db',
  'module' => 'QA_CollectionPlan',
  'bean_name' => 'QA_CollectionPlan',
  'side' => 'right',
  'vname' => 'LBL_QA_COLLECTIONPLAN_QA_COLLECTIONELEMENT_FROM_QA_COLLECTIONPLAN_TITLE',
);
