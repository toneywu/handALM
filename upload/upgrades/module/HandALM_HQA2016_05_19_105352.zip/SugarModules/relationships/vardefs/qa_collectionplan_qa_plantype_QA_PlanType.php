<?php
// created: 2016-05-19 10:53:45
$dictionary["QA_PlanType"]["fields"]["qa_collectionplan_qa_plantype"] = array (
  'name' => 'qa_collectionplan_qa_plantype',
  'type' => 'link',
  'relationship' => 'qa_collectionplan_qa_plantype',
  'source' => 'non-db',
  'module' => 'QA_CollectionPlan',
  'bean_name' => 'QA_CollectionPlan',
  'side' => 'right',
  'vname' => 'LBL_QA_COLLECTIONPLAN_QA_PLANTYPE_FROM_QA_COLLECTIONPLAN_TITLE',
);
