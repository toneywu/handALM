<?php
// created: 2016-05-19 10:53:40
$dictionary["QA_ElementType"]["fields"]["qa_collectionelement_qa_elementtype"] = array (
  'name' => 'qa_collectionelement_qa_elementtype',
  'type' => 'link',
  'relationship' => 'qa_collectionelement_qa_elementtype',
  'source' => 'non-db',
  'module' => 'QA_CollectionElement',
  'bean_name' => 'QA_CollectionElement',
  'side' => 'right',
  'vname' => 'LBL_QA_COLLECTIONELEMENT_QA_ELEMENTTYPE_FROM_QA_COLLECTIONELEMENT_TITLE',
);
