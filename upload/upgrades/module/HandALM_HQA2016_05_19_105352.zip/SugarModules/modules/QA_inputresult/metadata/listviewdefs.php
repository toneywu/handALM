<?php
$module_name = 'QA_inputresult';
$listViewDefs [$module_name] = 
array (
  'QA_INPUTRESULT_QA_COLLECTIONPLAN_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_QA_INPUTRESULT_QA_COLLECTIONPLAN_FROM_QA_COLLECTIONPLAN_TITLE',
    'id' => 'QA_INPUTRESULT_QA_COLLECTIONPLANQA_COLLECTIONPLAN_IDA',
    'width' => '10%',
    'default' => true,
  ),
);
?>
