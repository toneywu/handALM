sugarcrm_filepickerio
=====================

SugarCRM SugarField for utilizing the Filepicker.io service for record file attachments

Release History
---------------

2012-10-24
* Initial release

2012-01-23
* Added support for entering API key via Connectors API interface
* Removed putting README.md file in the build package; now passed Sugar On Demand package scanner.