<?php
// created: 2016-03-31 19:25:17
$dictionary[""]["fields"]["hat_counting_lines_hat_counting_batchs"] = array (
  'name' => 'hat_counting_lines_hat_counting_batchs',
  'type' => 'link',
  'relationship' => 'hat_counting_lines_hat_counting_batchs',
  'source' => 'non-db',
  'module' => 'HAT_Counting_Lines',
  'bean_name' => 'HAT_Counting_Lines',
  'side' => 'right',
  'vname' => 'LBL_HAT_COUNTING_LINES_HAT_COUNTING_BATCHS_FROM_HAT_COUNTING_LINES_TITLE',
);
