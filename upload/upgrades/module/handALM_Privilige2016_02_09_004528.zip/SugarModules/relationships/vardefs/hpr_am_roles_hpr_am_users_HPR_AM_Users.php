<?php
// created: 2016-02-08 18:13:36
$dictionary["HPR_AM_Users"]["fields"]["hpr_am_roles_hpr_am_users"] = array (
  'name' => 'hpr_am_roles_hpr_am_users',
  'type' => 'link',
  'relationship' => 'hpr_am_roles_hpr_am_users',
  'source' => 'non-db',
  'module' => 'HPR_AM_Roles',
  'bean_name' => 'HPR_AM_Roles',
  'vname' => 'LBL_HPR_AM_ROLES_HPR_AM_USERS_FROM_HPR_AM_ROLES_TITLE',
);
