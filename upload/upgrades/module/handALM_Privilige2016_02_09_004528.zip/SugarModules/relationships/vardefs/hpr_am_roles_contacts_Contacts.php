<?php
// created: 2016-02-09 00:45:28
$dictionary["Contact"]["fields"]["hpr_am_roles_contacts"] = array (
  'name' => 'hpr_am_roles_contacts',
  'type' => 'link',
  'relationship' => 'hpr_am_roles_contacts',
  'source' => 'non-db',
  'module' => 'HPR_AM_Roles',
  'bean_name' => 'HPR_AM_Roles',
  'vname' => 'LBL_HPR_AM_ROLES_CONTACTS_FROM_HPR_AM_ROLES_TITLE',
);
