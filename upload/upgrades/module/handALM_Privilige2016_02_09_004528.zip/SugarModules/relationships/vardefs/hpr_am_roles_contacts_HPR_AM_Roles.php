<?php
// created: 2016-02-09 00:45:28
$dictionary["HPR_AM_Roles"]["fields"]["hpr_am_roles_contacts"] = array (
  'name' => 'hpr_am_roles_contacts',
  'type' => 'link',
  'relationship' => 'hpr_am_roles_contacts',
  'source' => 'non-db',
  'module' => 'Contacts',
  'bean_name' => 'Contact',
  'vname' => 'LBL_HPR_AM_ROLES_CONTACTS_FROM_CONTACTS_TITLE',
);
