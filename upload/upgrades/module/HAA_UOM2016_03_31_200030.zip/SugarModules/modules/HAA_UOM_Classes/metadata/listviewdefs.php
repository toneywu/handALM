<?php
$module_name = 'HAA_UOM_Classes';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'BASE_UNIT_CODE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_BASE_UNIT_CODE',
    'width' => '10%',
    'default' => true,
  ),
);
?>
