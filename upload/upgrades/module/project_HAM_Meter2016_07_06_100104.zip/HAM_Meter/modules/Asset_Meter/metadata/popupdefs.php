<?php
$popupMeta = array (
    'moduleMain' => 'HMET_Asset_Meter',
    'varName' => 'HMET_Asset_Meter',
    'orderBy' => 'hmet_asset_meter.name',
    'whereClauses' => array (
  'name' => 'hmet_asset_meter.name',
  'asset' => 'hmet_asset_meter.asset',
),
    'searchInputs' => array (
  1 => 'name',
  4 => 'asset',
),
    'searchdefs' => array (
  'name' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'name' => 'name',
  ),
  'asset' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_ASSET',
    'id' => 'HAT_ASSETS_ID_C',
    'link' => true,
    'width' => '10%',
    'name' => 'asset',
  ),
),
    'listviewdefs' => array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'link' => true,
    'type' => 'relate',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'id' => 'ASSIGNED_USER_ID',
    'width' => '10%',
    'default' => true,
  ),
),
);
