<?php
$module_name = 'CUX_DEMO';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'COST' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_COST',
    'width' => '10%',
    'default' => true,
  ),
  'PRICE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PRICE',
    'width' => '10%',
    'default' => true,
  ),
);
?>
