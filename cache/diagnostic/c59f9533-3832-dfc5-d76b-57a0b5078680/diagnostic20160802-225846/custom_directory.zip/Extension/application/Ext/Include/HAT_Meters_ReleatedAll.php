<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HAT_Meters'] = 'HAT_Meters';
$beanFiles['HAT_Meters'] = 'modules/HAT_Meters/HAT_Meters.php';
$moduleList[] = 'HAT_Meters';
/*$modules_exempt_from_availability_check['HAT_Meters'] = 'HAT_Meters';
$report_include_modules['HAT_Meters'] = 'HAT_Meters';
$modInvisList[] = 'HAT_Meters';
*/
 //WARNING: The contents of this file are auto-generated
$beanList['HAT_Meter_Types'] = 'HAT_Meter_Types';
$beanFiles['HAT_Meter_Types'] = 'modules/HAT_Meter_Types/HAT_Meter_Types.php';
$moduleList[] = 'HAT_Meter_Types';
/*$modules_exempt_from_availability_check['HAT_Meter_Types'] = 'HAT_Meter_Types';
$report_include_modules['HAT_Meter_Types'] = 'HAT_Meter_Types';
$modInvisList[] = 'HAT_Meter_Types';
*/
 //WARNING: The contents of this file are auto-generated
$beanList['HAT_Meter_Readings'] = 'HAT_Meter_Readings';
$beanFiles['HAT_Meter_Readings'] = 'modules/HAT_Meter_Readings/HAT_Meter_Readings.php';
$moduleList[] = 'HAT_Meter_Readings';
/*$modules_exempt_from_availability_check['HAT_Meter_Readings'] = 'HAT_Meter_Readings';
$report_include_modules['HAT_Meter_Readings'] = 'HAT_Meter_Readings';
$modInvisList[] = 'HAT_Meter_Readings';
*/
?>