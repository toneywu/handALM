<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HAM_Work_Center_People'] = 'HAM_Work_Center_People';
$beanFiles['HAM_Work_Center_People'] = 'modules/HAM_Work_Center_People/HAM_Work_Center_People.php';
$moduleList[] = 'HAM_Work_Center_People';

?>