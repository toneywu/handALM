<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HAM_WOOP'] = 'HAM_WOOP';
$beanFiles['HAM_WOOP'] = 'modules/HAM_WOOP/HAM_WOOP.php';
$moduleList[] = 'HAM_WOOP';

?>