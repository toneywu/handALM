<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/hat_counting_lines_hat_counting_batchsMetaData.php');

?>