<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HIT_Rack_Allocations'] = 'HIT_Rack_Allocations';
$beanFiles['HIT_Rack_Allocations'] = 'modules/HIT_Rack_Allocations/HIT_Rack_Allocations.php';
$moduleList[] = 'HIT_Rack_Allocations';

?>