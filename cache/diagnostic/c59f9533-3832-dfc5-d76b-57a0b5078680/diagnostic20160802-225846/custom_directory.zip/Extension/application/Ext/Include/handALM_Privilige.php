<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HPR_AM_Catelog'] = 'HPR_AM_Catelog';
$beanFiles['HPR_AM_Catelog'] = 'modules/HPR_AM_Catelog/HPR_AM_Catelog.php';
$moduleList[] = 'HPR_AM_Catelog';
$beanList['HPR_AM_Roles'] = 'HPR_AM_Roles';
$beanFiles['HPR_AM_Roles'] = 'modules/HPR_AM_Roles/HPR_AM_Roles.php';
$moduleList[] = 'HPR_AM_Roles';

?>