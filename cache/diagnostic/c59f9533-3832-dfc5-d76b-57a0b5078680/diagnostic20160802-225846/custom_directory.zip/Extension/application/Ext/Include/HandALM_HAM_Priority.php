<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HAM_Priority'] = 'HAM_Priority';
$beanFiles['HAM_Priority'] = 'modules/HAM_Priority/HAM_Priority.php';
$moduleList[] = 'HAM_Priority';

?>