<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HMM_Locators'] = 'HMM_Locators';
$beanFiles['HMM_Locators'] = 'modules/HMM_Locators/HMM_Locators.php';
$moduleList[] = 'HMM_Locators';

?>