<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HAA_QUAL'] = 'HAA_QUAL';
$beanFiles['HAA_QUAL'] = 'modules/HAA_QUAL/HAA_QUAL.php';
$moduleList[] = 'HAA_QUAL';

?>