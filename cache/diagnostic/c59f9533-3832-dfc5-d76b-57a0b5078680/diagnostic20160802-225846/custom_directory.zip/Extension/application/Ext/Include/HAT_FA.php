<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HAT_FA'] = 'HAT_FA';
$beanFiles['HAT_FA'] = 'modules/HAT_FA/HAT_FA.php';
$moduleList[] = 'HAT_FA';

?>