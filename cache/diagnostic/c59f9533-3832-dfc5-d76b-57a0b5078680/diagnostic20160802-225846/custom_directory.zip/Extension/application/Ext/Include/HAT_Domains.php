<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HAT_Domains'] = 'HAT_Domains';
$beanFiles['HAT_Domains'] = 'modules/HAT_Domains/HAT_Domains.php';
$moduleList[] = 'HAT_Domains';

?>