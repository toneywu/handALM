<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HAA_UOM'] = 'HAA_UOM';
$beanFiles['HAA_UOM'] = 'modules/HAA_UOM/HAA_UOM.php';
$moduleList[] = 'HAA_UOM';
$beanList['HAA_UOM_Classes'] = 'HAA_UOM_Classes';
$beanFiles['HAA_UOM_Classes'] = 'modules/HAA_UOM_Classes/HAA_UOM_Classes.php';
$moduleList[] = 'HAA_UOM_Classes';
$beanList['HAA_UOM_Conversions'] = 'HAA_UOM_Conversions';
$beanFiles['HAA_UOM_Conversions'] = 'modules/HAA_UOM_Conversions/HAA_UOM_Conversions.php';
$moduleList[] = 'HAA_UOM_Conversions';

?>