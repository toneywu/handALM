<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/hpr_am_roles_contactsMetaData.php');

?>