<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HAA_Maps'] = 'HAA_Maps';
$beanFiles['HAA_Maps'] = 'modules/HAA_Maps/HAA_Maps.php';
$moduleList[] = 'HAA_Maps';

?>