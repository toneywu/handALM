<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HAM_Work_Centers'] = 'HAM_Work_Centers';
$beanFiles['HAM_Work_Centers'] = 'modules/HAM_Work_Centers/HAM_Work_Centers.php';
$moduleList[] = 'HAM_Work_Centers';

?>