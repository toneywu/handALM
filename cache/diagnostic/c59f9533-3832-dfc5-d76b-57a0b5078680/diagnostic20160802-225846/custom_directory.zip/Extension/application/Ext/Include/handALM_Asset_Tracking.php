<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HAT_Assets'] = 'HAT_Assets';
$beanFiles['HAT_Assets'] = 'modules/HAT_Assets/HAT_Assets.php';
$moduleList[] = 'HAT_Assets';
$beanList['HAT_Asset_Locations'] = 'HAT_Asset_Locations';
$beanFiles['HAT_Asset_Locations'] = 'modules/HAT_Asset_Locations/HAT_Asset_Locations.php';
$moduleList[] = 'HAT_Asset_Locations';
$beanList['HAT_Asset_Trans'] = 'HAT_Asset_Trans';
$beanFiles['HAT_Asset_Trans'] = 'modules/HAT_Asset_Trans/HAT_Asset_Trans.php';
$moduleList[] = 'HAT_Asset_Trans';
$beanList['HAT_Asset_Trans_Batch'] = 'HAT_Asset_Trans_Batch';
$beanFiles['HAT_Asset_Trans_Batch'] = 'modules/HAT_Asset_Trans_Batch/HAT_Asset_Trans_Batch.php';
$moduleList[] = 'HAT_Asset_Trans_Batch';

?>