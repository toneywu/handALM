<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HAM_ACT_OP'] = 'HAM_ACT_OP';
$beanFiles['HAM_ACT_OP'] = 'modules/HAM_ACT_OP/HAM_ACT_OP.php';
$moduleList[] = 'HAM_ACT_OP';

?>