<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HAM_HAM_Subinv'] = 'HAM_HAM_Subinv';
$beanFiles['HAM_HAM_Subinv'] = 'modules/HAM_HAM_Subinv/HAM_HAM_Subinv.php';
$moduleList[] = 'HAM_HAM_Subinv';
$beanList['HAM_Maint_Sites'] = 'HAM_Maint_Sites';
$beanFiles['HAM_Maint_Sites'] = 'modules/HAM_Maint_Sites/HAM_Maint_Sites.php';
$moduleList[] = 'HAM_Maint_Sites';

?>