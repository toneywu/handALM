<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HAA_FF'] = 'HAA_FF';
$beanFiles['HAA_FF'] = 'modules/HAA_FF/HAA_FF.php';
$moduleList[] = 'HAA_FF';
$beanList['HAA_FF_Conditions'] = 'HAA_FF_Conditions';
$beanFiles['HAA_FF_Conditions'] = 'modules/HAA_FF_Conditions/HAA_FF_Conditions.php';
$modules_exempt_from_availability_check['HAA_FF_Conditions'] = 'HAA_FF_Conditions';
$report_include_modules['HAA_FF_Conditions'] = 'HAA_FF_Conditions';
$modInvisList[] = 'HAA_FF_Conditions';
$beanList['HAA_FF_Fields'] = 'HAA_FF_Fields';
$beanFiles['HAA_FF_Fields'] = 'modules/HAA_FF_Fields/HAA_FF_Fields.php';
$modules_exempt_from_availability_check['HAA_FF_Fields'] = 'HAA_FF_Fields';
$report_include_modules['HAA_FF_Fields'] = 'HAA_FF_Fields';
$modInvisList[] = 'HAA_FF_Fields';

?>