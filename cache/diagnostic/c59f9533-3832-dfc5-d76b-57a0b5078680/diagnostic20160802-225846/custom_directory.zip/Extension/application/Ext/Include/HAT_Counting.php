<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HAT_Counting_Batchs'] = 'HAT_Counting_Batchs';
$beanFiles['HAT_Counting_Batchs'] = 'modules/HAT_Counting_Batchs/HAT_Counting_Batchs.php';
$moduleList[] = 'HAT_Counting_Batchs';
$beanList['HAT_Counting_Lines'] = 'HAT_Counting_Lines';
$beanFiles['HAT_Counting_Lines'] = 'modules/HAT_Counting_Lines/HAT_Counting_Lines.php';
$moduleList[] = 'HAT_Counting_Lines';

?>