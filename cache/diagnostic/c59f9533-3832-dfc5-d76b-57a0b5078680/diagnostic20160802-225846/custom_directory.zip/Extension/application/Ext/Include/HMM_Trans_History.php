<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HMM_Trans_History'] = 'HMM_Trans_History';
$beanFiles['HMM_Trans_History'] = 'modules/HMM_Trans_History/HMM_Trans_History.php';
$moduleList[] = 'HMM_Trans_History';

?>