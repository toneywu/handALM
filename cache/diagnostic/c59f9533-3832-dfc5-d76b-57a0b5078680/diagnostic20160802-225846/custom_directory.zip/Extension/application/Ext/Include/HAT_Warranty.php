<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HAT_Warranty_Types'] = 'HAT_Warranty_Types';
$beanFiles['HAT_Warranty_Types'] = 'modules/HAT_Warranty_Types/HAT_Warranty_Types.php';
$moduleList[] = 'HAT_Warranty_Types';

?>