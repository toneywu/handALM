<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HMM_MO_Requests'] = 'HMM_MO_Requests';
$beanFiles['HMM_MO_Requests'] = 'modules/HMM_MO_Requests/HMM_MO_Requests.php';
$moduleList[] = 'HMM_MO_Requests';
$beanList['HMM_MO_Request_Lines'] = 'HMM_MO_Request_Lines';
$beanFiles['HMM_MO_Request_Lines'] = 'modules/HMM_MO_Request_Lines/HMM_MO_Request_Lines.php';
$moduleList[] = 'HMM_MO_Request_Lines';
$beanList['HMM_Trans_Batch'] = 'HMM_Trans_Batch';
$beanFiles['HMM_Trans_Batch'] = 'modules/HMM_Trans_Batch/HMM_Trans_Batch.php';
$moduleList[] = 'HMM_Trans_Batch';
$beanList['HMM_Trans_Lines'] = 'HMM_Trans_Lines';
$beanFiles['HMM_Trans_Lines'] = 'modules/HMM_Trans_Lines/HMM_Trans_Lines.php';
$moduleList[] = 'HMM_Trans_Lines';

?>