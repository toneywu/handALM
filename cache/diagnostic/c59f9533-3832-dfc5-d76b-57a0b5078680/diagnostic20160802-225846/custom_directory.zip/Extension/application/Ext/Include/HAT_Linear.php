<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HAT_Linear_Elements'] = 'HAT_Linear_Elements';
$beanFiles['HAT_Linear_Elements'] = 'modules/HAT_Linear_Elements/HAT_Linear_Elements.php';
$moduleList[] = 'HAT_Linear_Elements';
$beanList['HAT_Linear_Reference_Methods'] = 'HAT_Linear_Reference_Methods';
$beanFiles['HAT_Linear_Reference_Methods'] = 'modules/HAT_Linear_Reference_Methods/HAT_Linear_Reference_Methods.php';
$moduleList[] = 'HAT_Linear_Reference_Methods';
$beanList['HAT_Linear_Relationships'] = 'HAT_Linear_Relationships';
$beanFiles['HAT_Linear_Relationships'] = 'modules/HAT_Linear_Relationships/HAT_Linear_Relationships.php';
$moduleList[] = 'HAT_Linear_Relationships';
$beanList['HAT_Linear_Spec'] = 'HAT_Linear_Spec';
$beanFiles['HAT_Linear_Spec'] = 'modules/HAT_Linear_Spec/HAT_Linear_Spec.php';
$moduleList[] = 'HAT_Linear_Spec';

?>