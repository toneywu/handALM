<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HAM_SR'] = 'HAM_SR';
$beanFiles['HAM_SR'] = 'modules/HAM_SR/HAM_SR.php';
$moduleList[] = 'HAM_SR';

?>