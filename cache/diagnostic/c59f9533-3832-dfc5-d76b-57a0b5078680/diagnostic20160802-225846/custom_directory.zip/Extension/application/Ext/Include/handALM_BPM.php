<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['ABP_BPM_Actions'] = 'ABP_BPM_Actions';
$beanFiles['ABP_BPM_Actions'] = 'modules/ABP_BPM_Actions/ABP_BPM_Actions.php';
$moduleList[] = 'ABP_BPM_Actions';

?>