<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HAT_Systems'] = 'HAT_Systems';
$beanFiles['HAT_Systems'] = 'modules/HAT_Systems/HAT_Systems.php';
$moduleList[] = 'HAT_Systems';

?>