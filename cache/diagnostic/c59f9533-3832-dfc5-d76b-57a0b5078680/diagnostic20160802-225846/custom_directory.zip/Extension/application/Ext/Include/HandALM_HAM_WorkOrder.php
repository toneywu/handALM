<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HAM_WO'] = 'HAM_WO';
$beanFiles['HAM_WO'] = 'modules/HAM_WO/HAM_WO.php';
$moduleList[] = 'HAM_WO';

?>