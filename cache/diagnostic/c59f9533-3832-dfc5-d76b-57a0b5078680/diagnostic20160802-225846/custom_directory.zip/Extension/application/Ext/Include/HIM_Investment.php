<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HIM_IM_Budget_Revisions'] = 'HIM_IM_Budget_Revisions';
$beanFiles['HIM_IM_Budget_Revisions'] = 'modules/HIM_IM_Budget_Revisions/HIM_IM_Budget_Revisions.php';
$moduleList[] = 'HIM_IM_Budget_Revisions';
$beanList['HIM_IM_Categories'] = 'HIM_IM_Categories';
$beanFiles['HIM_IM_Categories'] = 'modules/HIM_IM_Categories/HIM_IM_Categories.php';
$moduleList[] = 'HIM_IM_Categories';
$beanList['HIM_Programs'] = 'HIM_Programs';
$beanFiles['HIM_Programs'] = 'modules/HIM_Programs/HIM_Programs.php';
$moduleList[] = 'HIM_Programs';
$beanList['HIM_Project_Budgets'] = 'HIM_Project_Budgets';
$beanFiles['HIM_Project_Budgets'] = 'modules/HIM_Project_Budgets/HIM_Project_Budgets.php';
$moduleList[] = 'HIM_Project_Budgets';
$beanList['HIM_Project_Requests'] = 'HIM_Project_Requests';
$beanFiles['HIM_Project_Requests'] = 'modules/HIM_Project_Requests/HIM_Project_Requests.php';
$moduleList[] = 'HIM_Project_Requests';
$beanList['HIM_Project_Tasks'] = 'HIM_Project_Tasks';
$beanFiles['HIM_Project_Tasks'] = 'modules/HIM_Project_Tasks/HIM_Project_Tasks.php';
$moduleList[] = 'HIM_Project_Tasks';

?>