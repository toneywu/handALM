<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['CUX_Demo'] = 'CUX_Demo';
$beanFiles['CUX_Demo'] = 'modules/CUX_Demo/CUX_Demo.php';
$moduleList[] = 'CUX_Demo';

?>