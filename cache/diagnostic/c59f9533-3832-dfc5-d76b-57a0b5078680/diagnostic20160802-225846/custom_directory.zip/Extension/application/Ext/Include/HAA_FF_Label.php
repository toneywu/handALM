<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HAA_FF_Labels'] = 'HAA_FF_Labels';
$beanFiles['HAA_FF_Labels'] = 'modules/HAA_FF_Labels/HAA_FF_Labels.php';
$modules_exempt_from_availability_check['HAA_FF_Labels'] = 'HAA_FF_Labels';
$report_include_modules['HAA_FF_Labels'] = 'HAA_FF_Labels';
$modInvisList[] = 'HAA_FF_Labels';

?>