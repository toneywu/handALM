<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HAM_ACT'] = 'HAM_ACT';
$beanFiles['HAM_ACT'] = 'modules/HAM_ACT/HAM_ACT.php';
$moduleList[] = 'HAM_ACT';

?>