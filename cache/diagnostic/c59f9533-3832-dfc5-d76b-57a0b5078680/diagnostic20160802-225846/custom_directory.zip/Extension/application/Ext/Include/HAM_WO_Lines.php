<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HAM_WO_Lines'] = 'HAM_WO_Lines';
$beanFiles['HAM_WO_Lines'] = 'modules/HAM_WO_Lines/HAM_WO_Lines.php';
$moduleList[] = 'HAM_WO_Lines';

?>