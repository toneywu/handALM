<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HIT_IP_Subnets'] = 'HIT_IP_Subnets';
$beanFiles['HIT_IP_Subnets'] = 'modules/HIT_IP_Subnets/HIT_IP_Subnets.php';
$moduleList[] = 'HIT_IP_Subnets';

?>