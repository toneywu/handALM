<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HAT_Asset_QUAL'] = 'HAT_Asset_QUAL';
$beanFiles['HAT_Asset_QUAL'] = 'modules/HAT_Asset_QUAL/HAT_Asset_QUAL.php';
$moduleList[] = 'HAT_Asset_QUAL';
$beanList['HAT_Asset_QUAL_Details'] = 'HAT_Asset_QUAL_Details';
$beanFiles['HAT_Asset_QUAL_Details'] = 'modules/HAT_Asset_QUAL_Details/HAT_Asset_QUAL_Details.php';
$moduleList[] = 'HAT_Asset_QUAL_Details';

?>