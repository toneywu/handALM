<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/hat_assets_hat_asset_transMetaData.php');

?>