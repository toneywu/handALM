<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HAA_Numbering_Rule'] = 'HAA_Numbering_Rule';
$beanFiles['HAA_Numbering_Rule'] = 'modules/HAA_Numbering_Rule/HAA_Numbering_Rule.php';
$moduleList[] = 'HAA_Numbering_Rule';

?>