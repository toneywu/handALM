<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HIT_Racks'] = 'HIT_Racks';
$beanFiles['HIT_Racks'] = 'modules/HIT_Racks/HIT_Racks.php';
$moduleList[] = 'HIT_Racks';

?>