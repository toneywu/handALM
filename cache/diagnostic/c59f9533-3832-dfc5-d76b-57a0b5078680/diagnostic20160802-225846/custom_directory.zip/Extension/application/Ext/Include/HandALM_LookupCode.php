<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HAA_Codes'] = 'HAA_Codes';
$beanFiles['HAA_Codes'] = 'modules/HAA_Codes/HAA_Codes.php';
$moduleList[] = 'HAA_Codes';

?>