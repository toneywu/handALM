<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HAM_Work_Center_Res'] = 'HAM_Work_Center_Res';
$beanFiles['HAM_Work_Center_Res'] = 'modules/HAM_Work_Center_Res/HAM_Work_Center_Res.php';
$moduleList[] = 'HAM_Work_Center_Res';

?>