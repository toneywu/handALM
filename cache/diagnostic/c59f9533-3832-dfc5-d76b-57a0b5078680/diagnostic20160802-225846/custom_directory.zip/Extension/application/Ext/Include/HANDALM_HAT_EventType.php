<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HAT_EventType'] = 'HAT_EventType';
$beanFiles['HAT_EventType'] = 'modules/HAT_EventType/HAT_EventType.php';
$moduleList[] = 'HAT_EventType';

?>