<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/hat_asset_locations_hat_assetsMetaData.php');

?>