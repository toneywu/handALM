<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HAT_Properties'] = 'HAT_Properties';
$beanFiles['HAT_Properties'] = 'modules/HAT_Properties/HAT_Properties.php';
$moduleList[] = 'HAT_Properties';
$beanList['HAT_Opn_Locations'] = 'HAT_Opn_Locations';
$beanFiles['HAT_Opn_Locations'] = 'modules/HAT_Opn_Locations/HAT_Opn_Locations.php';
$moduleList[] = 'HAT_Opn_Locations';

?>