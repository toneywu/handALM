<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HIT_IP'] = 'HIT_IP';
$beanFiles['HIT_IP'] = 'modules/HIT_IP/HIT_IP.php';
$moduleList[] = 'HIT_IP';
$beanList['HIT_IP_Allocations'] = 'HIT_IP_Allocations';
$beanFiles['HIT_IP_Allocations'] = 'modules/HIT_IP_Allocations/HIT_IP_Allocations.php';
$moduleList[] = 'HIT_IP_Allocations';
$beanList['HIT_VLAN'] = 'HIT_VLAN';
$beanFiles['HIT_VLAN'] = 'modules/HIT_VLAN/HIT_VLAN.php';
$moduleList[] = 'HIT_VLAN';

?>