<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['HIT_Ports'] = 'HIT_Ports';
$beanFiles['HIT_Ports'] = 'modules/HIT_Ports/HIT_Ports.php';
$moduleList[] = 'HIT_Ports';

?>