<?php
//auto-generated file DO NOT EDIT
$layout_defs['HAT_Asset_QUAL']['subpanel_setup']['hat_asset_qual_details']['override_subpanel_name'] = 'HAT_Asset_QUAL_subpanel_hat_asset_qual_details';
?>