<?php
 // created: 2016-02-06 22:15:35
$dictionary['Prospect']['fields']['jjwg_maps_address_c']['inline_edit']=1;

 ?>