<?php
 // created: 2016-02-09 19:14:55
$dictionary['Contact']['fields']['last_name_c']['inline_edit']='1';
$dictionary['Contact']['fields']['last_name_c']['labelValue']='Last Name';

 ?>