<?php
//auto-generated file DO NOT EDIT
$layout_defs['Contacts']['subpanel_setup']['hpr_am_roles_contacts']['override_subpanel_name'] = 'Contact_subpanel_hpr_am_roles_contacts';
?>