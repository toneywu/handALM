<?php
 // created: 2016-02-16 18:15:00
$dictionary['Contact']['fields']['linked_user_c']['inline_edit']='1';
$dictionary['Contact']['fields']['linked_user_c']['labelValue']='Linked User';

 ?>