<?php
 // created: 2016-02-09 18:33:50
$dictionary['Contact']['fields']['chinese_name_c']['inline_edit']='1';
$dictionary['Contact']['fields']['chinese_name_c']['labelValue']='Chinese Name';

 ?>