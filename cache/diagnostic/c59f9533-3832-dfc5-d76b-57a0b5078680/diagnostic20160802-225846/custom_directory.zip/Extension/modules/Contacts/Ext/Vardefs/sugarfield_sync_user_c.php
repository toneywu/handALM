<?php
 // created: 2016-02-10 21:31:04
$dictionary['Contact']['fields']['sync_user_c']['inline_edit']='1';
$dictionary['Contact']['fields']['sync_user_c']['labelValue']='Sync User Information';

 ?>