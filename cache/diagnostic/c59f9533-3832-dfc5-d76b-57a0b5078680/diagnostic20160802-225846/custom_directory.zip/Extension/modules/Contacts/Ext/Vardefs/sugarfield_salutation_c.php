<?php
 // created: 2016-02-09 19:32:48
$dictionary['Contact']['fields']['salutation_c']['inline_edit']='1';
$dictionary['Contact']['fields']['salutation_c']['labelValue']='salutation';

 ?>