<?php
 // created: 2016-02-17 07:54:38
$dictionary['Contact']['fields']['type_c']['inline_edit']='';
$dictionary['Contact']['fields']['type_c']['labelValue']='Type';

 ?>