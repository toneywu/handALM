<?php
 // created: 2016-02-09 18:34:12
$dictionary['Contact']['fields']['employee_number_c']['inline_edit']='1';
$dictionary['Contact']['fields']['employee_number_c']['labelValue']='Employee Number';

 ?>