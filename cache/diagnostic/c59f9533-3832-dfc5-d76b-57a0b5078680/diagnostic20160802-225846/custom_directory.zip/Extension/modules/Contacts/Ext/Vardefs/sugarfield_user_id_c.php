<?php
 // created: 2016-02-16 18:15:00
$dictionary['Contact']['fields']['user_id_c']['inline_edit']=1;

 ?>