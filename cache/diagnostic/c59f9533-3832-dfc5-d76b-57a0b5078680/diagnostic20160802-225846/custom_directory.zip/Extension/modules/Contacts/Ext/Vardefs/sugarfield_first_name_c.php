<?php
 // created: 2016-02-09 19:14:37
$dictionary['Contact']['fields']['first_name_c']['inline_edit']='1';
$dictionary['Contact']['fields']['first_name_c']['labelValue']='First Name';

 ?>