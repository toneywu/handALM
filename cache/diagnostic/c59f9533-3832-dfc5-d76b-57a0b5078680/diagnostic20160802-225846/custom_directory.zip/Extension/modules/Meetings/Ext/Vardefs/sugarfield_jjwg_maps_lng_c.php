<?php
 // created: 2016-02-06 22:15:33
$dictionary['Meeting']['fields']['jjwg_maps_lng_c']['inline_edit']=1;

 ?>