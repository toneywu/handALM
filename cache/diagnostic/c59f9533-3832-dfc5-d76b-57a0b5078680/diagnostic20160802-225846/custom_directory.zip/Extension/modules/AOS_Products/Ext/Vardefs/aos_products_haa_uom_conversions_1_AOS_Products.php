<?php
// created: 2016-04-23 12:02:58
$dictionary["AOS_Products"]["fields"]["aos_products_haa_uom_conversions_1"] = array (
  'name' => 'aos_products_haa_uom_conversions_1',
  'type' => 'link',
  'relationship' => 'aos_products_haa_uom_conversions_1',
  'source' => 'non-db',
  'module' => 'HAA_UOM_Conversions',
  'bean_name' => 'HAA_UOM_Conversions',
  'side' => 'right',
  'vname' => 'LBL_AOS_PRODUCTS_HAA_UOM_CONVERSIONS_1_FROM_HAA_UOM_CONVERSIONS_TITLE',
);
