<?php
 // created: 2016-04-22 09:11:19
$dictionary['AOS_Products']['fields']['tracking_uom_c']['inline_edit']='';
$dictionary['AOS_Products']['fields']['tracking_uom_c']['labelValue']='Tracking by';

 ?>