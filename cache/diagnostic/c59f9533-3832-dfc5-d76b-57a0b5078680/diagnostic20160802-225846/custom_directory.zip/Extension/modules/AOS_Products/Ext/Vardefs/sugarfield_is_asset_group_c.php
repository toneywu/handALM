<?php
 // created: 2016-05-02 17:36:31
$dictionary['AOS_Products']['fields']['is_asset_group_c']['inline_edit']='';
$dictionary['AOS_Products']['fields']['is_asset_group_c']['labelValue']='Is Asset Group?';

 ?>