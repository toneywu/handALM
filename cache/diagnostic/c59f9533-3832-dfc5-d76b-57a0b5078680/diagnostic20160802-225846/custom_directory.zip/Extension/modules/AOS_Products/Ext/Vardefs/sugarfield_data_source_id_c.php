<?php
 // created: 2016-08-02 14:10:33
$dictionary['AOS_Products']['fields']['data_source_id_c']['inline_edit']='';
$dictionary['AOS_Products']['fields']['data_source_id_c']['labelValue']='Source ID';

 ?>