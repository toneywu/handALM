<?php
 // created: 2016-04-22 09:12:11
$dictionary['AOS_Products']['fields']['pricing_uom_c']['inline_edit']='';
$dictionary['AOS_Products']['fields']['pricing_uom_c']['labelValue']='Pricing by';

 ?>