<?php
 // created: 2016-04-22 09:08:02
$dictionary['AOS_Products']['fields']['haa_uom_id_c']['inline_edit']=1;

 ?>