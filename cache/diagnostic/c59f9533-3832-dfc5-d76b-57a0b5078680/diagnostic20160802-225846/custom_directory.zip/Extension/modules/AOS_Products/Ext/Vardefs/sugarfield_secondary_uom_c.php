<?php
 // created: 2016-04-22 09:09:11
$dictionary['AOS_Products']['fields']['secondary_uom_c']['inline_edit']='';
$dictionary['AOS_Products']['fields']['secondary_uom_c']['labelValue']='Secondary Unit';

 ?>