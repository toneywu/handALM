<?php
 // created: 2016-05-02 19:51:38
$dictionary['AOS_Products']['fields']['asset_num_perfix_c']['inline_edit']='';
$dictionary['AOS_Products']['fields']['asset_num_perfix_c']['labelValue']='Asset Num Perfix';

 ?>