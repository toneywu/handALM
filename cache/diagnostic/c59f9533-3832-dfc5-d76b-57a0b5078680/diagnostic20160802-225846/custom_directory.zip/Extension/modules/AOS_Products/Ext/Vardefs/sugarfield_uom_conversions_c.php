<?php
 // created: 2016-04-22 09:25:25
$dictionary['AOS_Products']['fields']['uom_conversions_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['uom_conversions_c']['labelValue']='UOM Conversions';

 ?>