<?php
//auto-generated file DO NOT EDIT
$layout_defs['AOS_Products']['subpanel_setup']['aos_products_haa_uom_conversions_1']['override_subpanel_name'] = 'AOS_Products_subpanel_aos_products_haa_uom_conversions_1';
?>