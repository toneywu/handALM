<?php
 // created: 2016-04-22 09:19:56
$dictionary['AOS_Products']['fields']['secondary_unit_defaulting_c']['inline_edit']='';
$dictionary['AOS_Products']['fields']['secondary_unit_defaulting_c']['labelValue']='Secondary Unit Defaulting';

 ?>