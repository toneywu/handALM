<?php
 // created: 2016-04-22 09:08:02
$dictionary['AOS_Products']['fields']['primary_uom_c']['inline_edit']='';
$dictionary['AOS_Products']['fields']['primary_uom_c']['labelValue']='Primary Unit';

 ?>