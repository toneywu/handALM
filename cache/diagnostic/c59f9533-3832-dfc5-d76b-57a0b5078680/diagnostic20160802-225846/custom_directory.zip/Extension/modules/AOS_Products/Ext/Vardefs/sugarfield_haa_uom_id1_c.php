<?php
 // created: 2016-04-22 09:08:50
$dictionary['AOS_Products']['fields']['haa_uom_id1_c']['inline_edit']=1;

 ?>