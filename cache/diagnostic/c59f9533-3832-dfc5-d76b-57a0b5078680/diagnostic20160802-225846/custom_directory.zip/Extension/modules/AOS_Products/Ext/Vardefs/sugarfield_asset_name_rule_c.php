<?php
 // created: 2016-05-02 19:48:36
$dictionary['AOS_Products']['fields']['asset_name_rule_c']['inline_edit']='';
$dictionary['AOS_Products']['fields']['asset_name_rule_c']['labelValue']='Asset Name Rule';

 ?>