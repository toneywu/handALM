<?php
 // created: 2016-07-04 00:31:25
$dictionary['AOS_Products']['fields']['flexform_c']['inline_edit']='';
$dictionary['AOS_Products']['fields']['flexform_c']['labelValue']='FlexForm';

 ?>