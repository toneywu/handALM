<?php
 // created: 2016-07-04 00:31:25
$dictionary['AOS_Products']['fields']['haa_ff_id_c']['inline_edit']=1;

 ?>