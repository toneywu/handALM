<?php
 // created: 2016-05-02 19:52:42
$dictionary['AOS_Products']['fields']['asset_num_padding_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['asset_num_padding_c']['labelValue']='Asset Num Padding';

 ?>