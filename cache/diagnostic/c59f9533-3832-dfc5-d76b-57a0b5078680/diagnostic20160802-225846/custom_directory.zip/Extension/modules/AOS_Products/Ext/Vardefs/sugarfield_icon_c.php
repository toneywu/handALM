<?php
 // created: 2016-08-02 14:10:52
$dictionary['AOS_Products']['fields']['icon_c']['inline_edit']='';
$dictionary['AOS_Products']['fields']['icon_c']['labelValue']='Icon';

 ?>