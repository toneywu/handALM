<?php
 // created: 2016-05-25 18:03:04
$dictionary['AOS_Products']['fields']['hat_domains_id_c']['inline_edit']=1;

 ?>