<?php
 // created: 2016-05-25 18:03:04
$dictionary['AOS_Products']['fields']['domain_c']['inline_edit']='';
$dictionary['AOS_Products']['fields']['domain_c']['labelValue']='Domain';

 ?>