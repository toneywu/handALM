<?php
 // created: 2016-08-02 14:09:20
$dictionary['AOS_Products']['fields']['data_source_code_c']['inline_edit']='';
$dictionary['AOS_Products']['fields']['data_source_code_c']['labelValue']='Source Code';

 ?>