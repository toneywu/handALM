<?php
 // created: 2016-08-02 14:10:04
$dictionary['AOS_Products']['fields']['data_source_reference_c']['inline_edit']='';
$dictionary['AOS_Products']['fields']['data_source_reference_c']['labelValue']='Source reference';

 ?>