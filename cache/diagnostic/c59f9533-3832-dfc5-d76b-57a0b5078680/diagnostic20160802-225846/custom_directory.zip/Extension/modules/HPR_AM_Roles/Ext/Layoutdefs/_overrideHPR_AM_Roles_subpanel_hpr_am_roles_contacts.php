<?php
//auto-generated file DO NOT EDIT
$layout_defs['HPR_AM_Roles']['subpanel_setup']['hpr_am_roles_contacts']['override_subpanel_name'] = 'HPR_AM_Roles_subpanel_hpr_am_roles_contacts';
?>