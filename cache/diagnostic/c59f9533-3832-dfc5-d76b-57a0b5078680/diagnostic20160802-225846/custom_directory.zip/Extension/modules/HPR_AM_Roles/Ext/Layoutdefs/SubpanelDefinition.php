<?php
$layout_defs["HPR_AM_Roles"]["subpanel_setup"]['hpr_am_roles_contacts']['top_buttons'] =
  array (
    0 => 
   /* array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => */
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ), /*
    2 => 
    array (
      'widget_class' => 'SubPanelTopFilterInputButton',
    ), */
  );
  /*
$layout_defs["HPR_AM_Roles"]["subpanel_setup"]['hpr_am_roles_contacts']['searchdefs'] =
array ( 'name' =>
        array (
            'name' => 'name',
            'default' => true,
            'width' => '10%',
        ),
    );

?>*/