<?php
 // created: 2016-08-02 13:09:02
$dictionary['AOS_Product_Categories']['fields']['data_source_reference_c']['inline_edit']='';
$dictionary['AOS_Product_Categories']['fields']['data_source_reference_c']['labelValue']='Source Reference';

 ?>