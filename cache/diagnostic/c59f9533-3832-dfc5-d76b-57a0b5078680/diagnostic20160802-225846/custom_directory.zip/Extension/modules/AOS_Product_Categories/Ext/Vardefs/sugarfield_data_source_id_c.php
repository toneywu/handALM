<?php
 // created: 2016-08-02 13:09:31
$dictionary['AOS_Product_Categories']['fields']['data_source_id_c']['inline_edit']='';
$dictionary['AOS_Product_Categories']['fields']['data_source_id_c']['labelValue']='Source ID';

 ?>