<?php
 // created: 2016-06-18 12:00:50
$dictionary['AOS_Contracts']['fields']['contract_number_c']['inline_edit']='';
$dictionary['AOS_Contracts']['fields']['contract_number_c']['labelValue']='Contract Number';

 ?>