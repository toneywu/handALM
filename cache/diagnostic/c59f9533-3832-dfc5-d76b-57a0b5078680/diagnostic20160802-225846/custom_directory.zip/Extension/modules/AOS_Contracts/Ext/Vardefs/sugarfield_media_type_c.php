<?php
 // created: 2016-06-18 11:50:43
$dictionary['AOS_Contracts']['fields']['media_type_c']['inline_edit']='';
$dictionary['AOS_Contracts']['fields']['media_type_c']['labelValue']='Media Type';

 ?>