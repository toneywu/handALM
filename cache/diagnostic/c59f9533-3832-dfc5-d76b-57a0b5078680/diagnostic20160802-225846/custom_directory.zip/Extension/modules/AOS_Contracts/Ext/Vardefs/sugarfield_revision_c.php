<?php
 // created: 2016-06-18 11:51:05
$dictionary['AOS_Contracts']['fields']['revision_c']['inline_edit']='';
$dictionary['AOS_Contracts']['fields']['revision_c']['labelValue']='Revision';

 ?>