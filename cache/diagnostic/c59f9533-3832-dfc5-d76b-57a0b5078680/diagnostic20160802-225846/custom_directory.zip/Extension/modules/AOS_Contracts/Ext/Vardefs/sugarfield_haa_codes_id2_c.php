<?php
 // created: 2016-06-18 11:50:43
$dictionary['AOS_Contracts']['fields']['haa_codes_id2_c']['inline_edit']=1;

 ?>