<?php
 // created: 2016-06-18 11:50:17
$dictionary['AOS_Contracts']['fields']['business_type_c']['inline_edit']='';
$dictionary['AOS_Contracts']['fields']['business_type_c']['labelValue']='Business Type';

 ?>