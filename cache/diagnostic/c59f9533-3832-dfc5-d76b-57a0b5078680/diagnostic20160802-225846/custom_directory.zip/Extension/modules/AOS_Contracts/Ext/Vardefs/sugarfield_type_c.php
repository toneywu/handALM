<?php
 // created: 2016-06-18 11:49:43
$dictionary['AOS_Contracts']['fields']['type_c']['inline_edit']='';
$dictionary['AOS_Contracts']['fields']['type_c']['labelValue']='Type';

 ?>