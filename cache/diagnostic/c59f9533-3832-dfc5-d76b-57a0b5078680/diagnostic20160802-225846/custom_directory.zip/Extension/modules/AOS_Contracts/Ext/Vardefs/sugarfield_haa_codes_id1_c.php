<?php
 // created: 2016-06-18 11:50:17
$dictionary['AOS_Contracts']['fields']['haa_codes_id1_c']['inline_edit']=1;

 ?>