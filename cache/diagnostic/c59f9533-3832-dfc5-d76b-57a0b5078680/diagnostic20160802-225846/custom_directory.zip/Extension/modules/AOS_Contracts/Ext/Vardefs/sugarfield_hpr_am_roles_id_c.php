<?php
 // created: 2016-06-18 11:51:05
$dictionary['AOS_Contracts']['fields']['hpr_am_roles_id_c']['inline_edit']=1;

 ?>