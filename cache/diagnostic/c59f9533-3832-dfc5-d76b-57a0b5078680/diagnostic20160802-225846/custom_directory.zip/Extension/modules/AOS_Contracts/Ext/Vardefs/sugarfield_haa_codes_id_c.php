<?php
 // created: 2016-06-18 11:49:43
$dictionary['AOS_Contracts']['fields']['haa_codes_id_c']['inline_edit']=1;

 ?>