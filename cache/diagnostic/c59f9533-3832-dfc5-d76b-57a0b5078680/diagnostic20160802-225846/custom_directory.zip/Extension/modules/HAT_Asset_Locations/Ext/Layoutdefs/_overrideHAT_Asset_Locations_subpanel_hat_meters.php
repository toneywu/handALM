<?php
//auto-generated file DO NOT EDIT
$layout_defs['HAT_Asset_Locations']['subpanel_setup']['hat_meters']['override_subpanel_name'] = 'HAT_Asset_Locations_subpanel_hat_meters';
?>