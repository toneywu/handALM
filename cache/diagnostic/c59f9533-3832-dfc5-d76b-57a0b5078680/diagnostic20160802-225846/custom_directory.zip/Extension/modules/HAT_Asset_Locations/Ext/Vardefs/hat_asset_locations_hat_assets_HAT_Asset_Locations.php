<?php
// created: 2016-02-08 10:53:31
$dictionary["HAT_Asset_Locations"]["fields"]["hat_asset_locations_hat_assets"] = array (
  'name' => 'hat_asset_locations_hat_assets',
  'type' => 'link',
  'relationship' => 'hat_asset_locations_hat_assets',
  'source' => 'non-db',
  'module' => 'HAT_Assets',
  'bean_name' => 'HAT_Assets',
  'side' => 'right',
  'vname' => 'LBL_HAT_ASSET_LOCATIONS_HAT_ASSETS_FROM_HAT_ASSETS_TITLE',
);
