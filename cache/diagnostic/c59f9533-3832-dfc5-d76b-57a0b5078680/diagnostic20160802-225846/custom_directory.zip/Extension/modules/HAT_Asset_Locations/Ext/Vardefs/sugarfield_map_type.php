<?php
 // created: 2016-03-23 16:11:30
$dictionary['HAT_Asset_Locations']['fields']['map_type']['default']='NONE';
$dictionary['HAT_Asset_Locations']['fields']['map_type']['required']=true;

 ?>