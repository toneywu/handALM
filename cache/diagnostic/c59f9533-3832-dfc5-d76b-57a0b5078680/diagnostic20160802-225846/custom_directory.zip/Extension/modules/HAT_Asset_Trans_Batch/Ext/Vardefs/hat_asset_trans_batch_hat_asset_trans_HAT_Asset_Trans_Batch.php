<?php
// created: 2016-02-08 10:53:31
$dictionary["HAT_Asset_Trans_Batch"]["fields"]["hat_asset_trans_batch_hat_asset_trans"] = array (
  'name' => 'hat_asset_trans_batch_hat_asset_trans',
  'type' => 'link',
  'relationship' => 'hat_asset_trans_batch_hat_asset_trans',
  'source' => 'non-db',
  'module' => 'HAT_Asset_Trans',
  'bean_name' => 'HAT_Asset_Trans',
  'side' => 'right',
  'vname' => 'LBL_HAT_ASSET_TRANS_BATCH_HAT_ASSET_TRANS_FROM_HAT_ASSET_TRANS_TITLE',
);
