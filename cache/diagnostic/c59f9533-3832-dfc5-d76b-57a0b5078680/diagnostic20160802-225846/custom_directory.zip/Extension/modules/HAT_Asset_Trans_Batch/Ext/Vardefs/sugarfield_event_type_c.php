<?php
 // created: 2016-02-20 20:12:50
$dictionary['HAT_Asset_Trans_Batch']['fields']['event_type_c']['inline_edit']='';
$dictionary['HAT_Asset_Trans_Batch']['fields']['event_type_c']['labelValue']='Event Type';

 ?>