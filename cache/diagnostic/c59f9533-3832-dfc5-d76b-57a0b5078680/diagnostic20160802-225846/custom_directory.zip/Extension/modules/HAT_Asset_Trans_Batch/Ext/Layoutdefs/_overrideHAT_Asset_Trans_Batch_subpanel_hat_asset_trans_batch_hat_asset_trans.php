<?php
//auto-generated file DO NOT EDIT
$layout_defs['HAT_Asset_Trans_Batch']['subpanel_setup']['hat_asset_trans_batch_hat_asset_trans']['override_subpanel_name'] = 'HAT_Asset_Trans_Batch_subpanel_hat_asset_trans_batch_hat_asset_trans';
?>