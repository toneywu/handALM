<?php
 // created: 2016-02-26 09:51:33
$dictionary['HAT_Asset_Trans_Batch']['fields']['target_organization_c']['inline_edit']='1';
$dictionary['HAT_Asset_Trans_Batch']['fields']['target_organization_c']['labelValue']='Target Organization';

 ?>