<?php
 // created: 2016-02-20 20:12:50
$dictionary['HAT_Asset_Trans_Batch']['fields']['hat_eventtype_id_c']['inline_edit']=1;

 ?>