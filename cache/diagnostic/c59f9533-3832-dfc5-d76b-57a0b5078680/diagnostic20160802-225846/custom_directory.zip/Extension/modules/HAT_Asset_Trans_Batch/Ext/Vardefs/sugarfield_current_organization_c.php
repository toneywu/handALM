<?php
 // created: 2016-02-17 12:42:51
$dictionary['HAT_Asset_Trans_Batch']['fields']['current_organization_c']['inline_edit']='';
$dictionary['HAT_Asset_Trans_Batch']['fields']['current_organization_c']['labelValue']='Current Organization';

 ?>