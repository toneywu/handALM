<?php
//auto-generated file DO NOT EDIT
$layout_defs['HAT_Assets']['subpanel_setup']['hat_meters']['override_subpanel_name'] = 'HAT_Assets_subpanel_hat_meters';
?>