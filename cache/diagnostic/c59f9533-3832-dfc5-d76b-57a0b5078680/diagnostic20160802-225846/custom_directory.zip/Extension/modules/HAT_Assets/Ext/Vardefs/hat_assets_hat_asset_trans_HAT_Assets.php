<?php
// created: 2016-02-08 10:53:31
$dictionary["HAT_Assets"]["fields"]["hat_assets_hat_asset_trans"] = array (
  'name' => 'hat_assets_hat_asset_trans',
  'type' => 'link',
  'relationship' => 'hat_assets_hat_asset_trans',
  'source' => 'non-db',
  'module' => 'HAT_Asset_Trans',
  'bean_name' => 'HAT_Asset_Trans',
  'side' => 'right',
  'vname' => 'LBL_HAT_ASSETS_HAT_ASSET_TRANS_FROM_HAT_ASSET_TRANS_TITLE',
);
