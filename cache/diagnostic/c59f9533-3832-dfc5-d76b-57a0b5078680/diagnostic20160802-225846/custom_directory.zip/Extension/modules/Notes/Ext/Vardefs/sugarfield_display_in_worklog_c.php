<?php
 // created: 2016-03-06 20:00:38
$dictionary['Note']['fields']['display_in_worklog_c']['inline_edit']=1;

 ?>