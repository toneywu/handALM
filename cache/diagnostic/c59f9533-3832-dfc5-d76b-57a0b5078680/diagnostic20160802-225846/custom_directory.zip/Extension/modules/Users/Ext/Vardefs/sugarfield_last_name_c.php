<?php
 // created: 2016-02-09 20:52:47
$dictionary['User']['fields']['last_name_c']['inline_edit']='1';
$dictionary['User']['fields']['last_name_c']['labelValue']='Last_Name';

 ?>