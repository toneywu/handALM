<?php
 // created: 2016-02-09 20:51:53
$dictionary['User']['fields']['chinese_name_c']['inline_edit']='1';
$dictionary['User']['fields']['chinese_name_c']['labelValue']='Chinese Name';

 ?>