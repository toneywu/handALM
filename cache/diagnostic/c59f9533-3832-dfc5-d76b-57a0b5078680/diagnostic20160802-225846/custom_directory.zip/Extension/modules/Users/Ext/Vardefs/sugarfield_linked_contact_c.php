<?php
 // created: 2016-02-16 17:33:31
$dictionary['User']['fields']['linked_contact_c']['inline_edit']='1';
$dictionary['User']['fields']['linked_contact_c']['labelValue']='Linked Contact';

 ?>