<?php
 // created: 2016-02-09 17:27:13
$dictionary['User']['fields']['asset_access_profile_c']['inline_edit']='1';
$dictionary['User']['fields']['asset_access_profile_c']['labelValue']='Asset Access Profile';

 ?>