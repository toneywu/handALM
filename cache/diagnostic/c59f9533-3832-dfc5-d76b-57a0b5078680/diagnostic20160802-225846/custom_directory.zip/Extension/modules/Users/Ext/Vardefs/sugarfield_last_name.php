<?php
 // created: 2016-02-10 10:46:19
$dictionary['User']['fields']['last_name']['required']=false;
$dictionary['User']['fields']['last_name']['inline_edit']=true;
$dictionary['User']['fields']['last_name']['merge_filter']='disabled';
$dictionary['User']['fields']['last_name']['default']='undefined';

 ?>