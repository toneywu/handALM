<?php
 // created: 2016-02-08 20:17:25
$dictionary['User']['fields']['account_id_c']['inline_edit']=1;

 ?>