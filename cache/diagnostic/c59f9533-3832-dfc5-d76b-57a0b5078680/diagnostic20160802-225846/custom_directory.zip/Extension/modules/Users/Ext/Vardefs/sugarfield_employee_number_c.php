<?php
 // created: 2016-02-10 10:42:35
$dictionary['User']['fields']['employee_number_c']['inline_edit']='1';
$dictionary['User']['fields']['employee_number_c']['labelValue']='Employee Number';

 ?>