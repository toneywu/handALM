<?php
 // created: 2016-02-10 10:39:51
$dictionary['User']['fields']['contact_organization_c']['inline_edit']='1';
$dictionary['User']['fields']['contact_organization_c']['labelValue']='Contact Organization';

 ?>