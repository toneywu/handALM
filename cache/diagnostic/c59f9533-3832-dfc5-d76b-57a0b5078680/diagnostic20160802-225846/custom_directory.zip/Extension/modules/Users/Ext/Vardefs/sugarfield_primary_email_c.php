<?php
 // created: 2016-02-11 14:05:17
$dictionary['User']['fields']['primary_email_c']['inline_edit']='1';
$dictionary['User']['fields']['primary_email_c']['labelValue']='Primary Email';

 ?>