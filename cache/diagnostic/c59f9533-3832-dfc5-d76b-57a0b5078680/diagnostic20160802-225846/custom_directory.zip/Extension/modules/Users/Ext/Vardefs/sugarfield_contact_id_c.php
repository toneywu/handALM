<?php
 // created: 2016-02-16 17:33:31
$dictionary['User']['fields']['contact_id_c']['inline_edit']=1;

 ?>