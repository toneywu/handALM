<?php
 // created: 2016-02-16 17:34:28
$dictionary['User']['fields']['sync_contact_c']['inline_edit']='1';
$dictionary['User']['fields']['sync_contact_c']['labelValue']='Sync Contact';

 ?>