<?php
 // created: 2016-02-09 20:52:24
$dictionary['User']['fields']['first_name_c']['inline_edit']='1';
$dictionary['User']['fields']['first_name_c']['labelValue']='First_Name';

 ?>