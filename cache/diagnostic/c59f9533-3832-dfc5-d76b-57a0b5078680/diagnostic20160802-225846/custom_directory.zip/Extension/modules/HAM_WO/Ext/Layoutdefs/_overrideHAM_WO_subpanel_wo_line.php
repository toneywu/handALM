<?php
//auto-generated file DO NOT EDIT
$layout_defs['HAM_WO']['subpanel_setup']['wo_line']['override_subpanel_name'] = 'HAM_WO_subpanel_wo_line';
?>