<?php
 // created: 2016-06-16 17:01:42
$dictionary['Account']['fields']['contact_id1_c']['inline_edit']=1;

 ?>