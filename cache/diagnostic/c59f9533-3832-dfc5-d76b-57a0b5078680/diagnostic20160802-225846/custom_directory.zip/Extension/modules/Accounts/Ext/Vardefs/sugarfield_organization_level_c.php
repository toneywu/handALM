<?php
 // created: 2016-06-16 16:47:57
$dictionary['Account']['fields']['organization_level_c']['inline_edit']='';
$dictionary['Account']['fields']['organization_level_c']['labelValue']='organization level';

 ?>