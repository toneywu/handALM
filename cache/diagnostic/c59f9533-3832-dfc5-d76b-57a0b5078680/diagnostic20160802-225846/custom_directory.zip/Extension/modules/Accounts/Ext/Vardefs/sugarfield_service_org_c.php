<?php
 // created: 2016-06-16 17:00:03
$dictionary['Account']['fields']['service_org_c']['inline_edit']='';
$dictionary['Account']['fields']['service_org_c']['labelValue']='Service Org. /Dept.';

 ?>