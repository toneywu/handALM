<?php
 // created: 2016-02-16 21:17:56
$dictionary['Account']['fields']['org_type_c']['inline_edit']='1';
$dictionary['Account']['fields']['org_type_c']['labelValue']='Org Type';

 ?>