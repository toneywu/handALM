<?php
 // created: 2016-06-16 17:00:03
$dictionary['Account']['fields']['account_id1_c']['inline_edit']=1;

 ?>