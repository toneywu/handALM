<?php
 // created: 2016-06-16 16:33:34
$dictionary['Account']['fields']['organization_number_c']['inline_edit']='';
$dictionary['Account']['fields']['organization_number_c']['labelValue']='organization number';

 ?>