<?php
 // created: 2016-06-16 16:59:36
$dictionary['Account']['fields']['account_id_c']['inline_edit']=1;

 ?>