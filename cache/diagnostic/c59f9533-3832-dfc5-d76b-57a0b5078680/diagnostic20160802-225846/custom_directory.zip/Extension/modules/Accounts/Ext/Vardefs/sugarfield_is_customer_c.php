<?php
 // created: 2016-06-16 16:54:08
$dictionary['Account']['fields']['is_customer_c']['inline_edit']='';
$dictionary['Account']['fields']['is_customer_c']['labelValue']='Is Customer?';

 ?>