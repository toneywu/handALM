<?php
 // created: 2016-07-25 07:18:28
$dictionary['Account']['fields']['attribute4_c']['inline_edit']='';
$dictionary['Account']['fields']['attribute4_c']['labelValue']='Attribute 4';

 ?>