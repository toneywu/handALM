<?php
 // created: 2016-02-16 21:16:20
$dictionary['Account']['fields']['registration_capital_c']['inline_edit']='1';
$dictionary['Account']['fields']['registration_capital_c']['labelValue']='Capital of Registration';

 ?>