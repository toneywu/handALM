<?php
 // created: 2016-02-16 20:45:05
$dictionary['Account']['fields']['is_ou_c']['inline_edit']='';
$dictionary['Account']['fields']['is_ou_c']['labelValue']='Operation Unit';

 ?>