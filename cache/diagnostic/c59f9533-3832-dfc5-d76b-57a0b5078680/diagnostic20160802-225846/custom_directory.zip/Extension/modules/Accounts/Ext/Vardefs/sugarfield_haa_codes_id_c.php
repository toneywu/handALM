<?php
 // created: 2016-06-16 16:47:57
$dictionary['Account']['fields']['haa_codes_id_c']['inline_edit']=1;

 ?>