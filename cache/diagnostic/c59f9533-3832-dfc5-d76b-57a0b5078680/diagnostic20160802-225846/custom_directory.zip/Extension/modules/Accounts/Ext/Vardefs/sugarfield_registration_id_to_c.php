<?php
 // created: 2016-02-16 21:03:19
$dictionary['Account']['fields']['registration_id_to_c']['inline_edit']='1';
$dictionary['Account']['fields']['registration_id_to_c']['labelValue']='Registration ID To';

 ?>