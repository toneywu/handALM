<?php
 // created: 2016-08-02 20:36:33
$dictionary['Account']['fields']['data_source_reference_c']['inline_edit']='';
$dictionary['Account']['fields']['data_source_reference_c']['labelValue']='Source Reference';

 ?>