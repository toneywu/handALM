<?php
 // created: 2016-07-25 07:55:20
$dictionary['Account']['fields']['business_type_c']['inline_edit']='';
$dictionary['Account']['fields']['business_type_c']['labelValue']='Business Type';

 ?>