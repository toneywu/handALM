<?php
 // created: 2016-02-16 20:55:43
$dictionary['Account']['fields']['full_name_c']['inline_edit']='1';
$dictionary['Account']['fields']['full_name_c']['labelValue']='Full Name';

 ?>