<?php
 // created: 2016-08-02 20:55:48
$dictionary['Account']['fields']['haa_codes_id2_c']['inline_edit']=1;

 ?>