<?php
 // created: 2016-06-16 16:50:53
$dictionary['Account']['fields']['haa_codes_id1_c']['inline_edit']=1;

 ?>