<?php
 // created: 2016-02-16 21:12:16
$dictionary['Account']['fields']['duns_number_c']['inline_edit']='1';
$dictionary['Account']['fields']['duns_number_c']['labelValue']='DUNS Number';

 ?>