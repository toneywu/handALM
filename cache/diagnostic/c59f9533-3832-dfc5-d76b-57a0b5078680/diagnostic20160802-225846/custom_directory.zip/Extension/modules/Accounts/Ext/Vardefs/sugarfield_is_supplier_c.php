<?php
 // created: 2016-06-16 16:54:35
$dictionary['Account']['fields']['is_supplier_c']['inline_edit']='';
$dictionary['Account']['fields']['is_supplier_c']['labelValue']='is supplier';

 ?>