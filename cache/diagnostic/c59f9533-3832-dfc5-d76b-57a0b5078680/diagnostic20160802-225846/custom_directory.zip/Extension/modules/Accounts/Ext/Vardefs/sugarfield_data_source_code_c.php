<?php
 // created: 2016-08-02 20:36:12
$dictionary['Account']['fields']['data_source_code_c']['inline_edit']='';
$dictionary['Account']['fields']['data_source_code_c']['labelValue']='Source Code';

 ?>