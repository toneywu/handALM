<?php
 // created: 2016-07-25 07:17:43
$dictionary['Account']['fields']['attribute2_c']['inline_edit']='';
$dictionary['Account']['fields']['attribute2_c']['labelValue']='Attribute 2';

 ?>