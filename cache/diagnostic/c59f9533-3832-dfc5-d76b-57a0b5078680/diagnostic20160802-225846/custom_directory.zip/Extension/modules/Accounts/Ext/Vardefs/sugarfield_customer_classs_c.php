<?php
 // created: 2016-08-02 20:55:48
$dictionary['Account']['fields']['customer_classs_c']['inline_edit']='';
$dictionary['Account']['fields']['customer_classs_c']['labelValue']='Customer Classs';

 ?>