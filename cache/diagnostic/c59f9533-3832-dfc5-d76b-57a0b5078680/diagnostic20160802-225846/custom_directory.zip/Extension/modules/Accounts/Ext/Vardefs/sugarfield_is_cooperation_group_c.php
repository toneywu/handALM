<?php
 // created: 2016-02-17 08:27:58
$dictionary['Account']['fields']['is_cooperation_group_c']['inline_edit']='1';
$dictionary['Account']['fields']['is_cooperation_group_c']['labelValue']='Cooperation Group';

 ?>