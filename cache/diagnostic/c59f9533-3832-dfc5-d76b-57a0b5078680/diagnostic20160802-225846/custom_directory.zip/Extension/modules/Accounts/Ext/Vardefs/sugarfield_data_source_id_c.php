<?php
 // created: 2016-08-02 20:36:53
$dictionary['Account']['fields']['data_source_id_c']['inline_edit']='';
$dictionary['Account']['fields']['data_source_id_c']['labelValue']='Source ID';

 ?>