<?php
 // created: 2016-06-16 16:39:27
$dictionary['Account']['fields']['responsible_person_note_c']['inline_edit']='';
$dictionary['Account']['fields']['responsible_person_note_c']['labelValue']='Responsible Person Note';

 ?>