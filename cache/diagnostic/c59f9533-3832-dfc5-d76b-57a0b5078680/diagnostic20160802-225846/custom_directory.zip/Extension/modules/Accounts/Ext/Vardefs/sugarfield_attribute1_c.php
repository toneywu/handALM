<?php
 // created: 2016-07-25 07:17:02
$dictionary['Account']['fields']['attribute1_c']['inline_edit']='';
$dictionary['Account']['fields']['attribute1_c']['labelValue']='Attribute 1';

 ?>