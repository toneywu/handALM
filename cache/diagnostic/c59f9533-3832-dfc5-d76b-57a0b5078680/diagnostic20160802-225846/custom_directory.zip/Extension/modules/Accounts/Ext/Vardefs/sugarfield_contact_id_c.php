<?php
 // created: 2016-06-16 17:01:11
$dictionary['Account']['fields']['contact_id_c']['inline_edit']=1;

 ?>