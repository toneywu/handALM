<?php
 // created: 2016-02-16 20:45:20
$dictionary['Account']['fields']['is_le_c']['inline_edit']='';
$dictionary['Account']['fields']['is_le_c']['labelValue']='Legal Entity';

 ?>