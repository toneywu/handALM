<?php
 // created: 2016-08-02 20:56:15
$dictionary['Account']['fields']['is_asset_org_c']['inline_edit']='';
$dictionary['Account']['fields']['is_asset_org_c']['labelValue']='资产组织？';

 ?>