<?php
 // created: 2016-06-16 17:01:11
$dictionary['Account']['fields']['sales_responsible_person_c']['inline_edit']='';
$dictionary['Account']['fields']['sales_responsible_person_c']['labelValue']='Sales Responsible Person';

 ?>