<?php
 // created: 2016-06-16 16:59:36
$dictionary['Account']['fields']['sales_org_c']['inline_edit']='';
$dictionary['Account']['fields']['sales_org_c']['labelValue']='Sales Org. /Dept.';

 ?>