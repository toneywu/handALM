<?php
 // created: 2016-06-16 16:38:40
$dictionary['Account']['fields']['responsible_person_id_c']['inline_edit']='';
$dictionary['Account']['fields']['responsible_person_id_c']['labelValue']='Responsible Person ID';

 ?>