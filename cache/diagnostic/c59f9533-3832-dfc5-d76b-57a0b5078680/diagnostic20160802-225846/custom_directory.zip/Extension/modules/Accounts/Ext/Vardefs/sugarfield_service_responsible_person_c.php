<?php
 // created: 2016-06-16 17:01:42
$dictionary['Account']['fields']['service_responsible_person_c']['inline_edit']='';
$dictionary['Account']['fields']['service_responsible_person_c']['labelValue']='Service Responsible Person';

 ?>