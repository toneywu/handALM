<?php
//auto-generated file DO NOT EDIT
$layout_defs['HIT_Racks']['subpanel_setup']['allocated_assets']['override_subpanel_name'] = 'HIT_Racks_subpanel_allocated_assets';
?>