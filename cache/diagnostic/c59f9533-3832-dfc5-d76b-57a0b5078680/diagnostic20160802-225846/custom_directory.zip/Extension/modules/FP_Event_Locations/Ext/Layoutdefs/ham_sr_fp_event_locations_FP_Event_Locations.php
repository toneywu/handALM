<?php
 // created: 2016-03-03 10:09:58
$layout_defs["FP_Event_Locations"]["subpanel_setup"]['ham_sr_fp_event_locations'] = array (
  'order' => 100,
  'module' => 'HAM_SR',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_HAM_SR_FP_EVENT_LOCATIONS_FROM_HAM_SR_TITLE',
  'get_subpanel_data' => 'ham_sr_fp_event_locations',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
