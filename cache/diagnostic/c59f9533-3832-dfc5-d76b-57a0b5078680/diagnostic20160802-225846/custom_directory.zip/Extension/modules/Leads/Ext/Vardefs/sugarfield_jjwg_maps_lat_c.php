<?php
 // created: 2016-02-06 22:15:32
$dictionary['Lead']['fields']['jjwg_maps_lat_c']['inline_edit']=1;

 ?>