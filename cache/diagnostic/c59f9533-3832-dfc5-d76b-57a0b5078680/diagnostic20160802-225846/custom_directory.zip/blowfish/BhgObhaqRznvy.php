<?php
// created: 2016-02-06 22:33:43
$key = array (
  0 => '8ecffb10-dfce-6f6f-7dca-56b6048f8989',
);