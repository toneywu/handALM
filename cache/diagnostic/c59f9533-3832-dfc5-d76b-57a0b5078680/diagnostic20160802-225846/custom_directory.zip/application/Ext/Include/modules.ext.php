<?php 
 //WARNING: The contents of this file are auto-generated

 
 //WARNING: The contents of this file are auto-generated
$beanList['CUX_Demo'] = 'CUX_Demo';
$beanFiles['CUX_Demo'] = 'modules/CUX_Demo/CUX_Demo.php';
$moduleList[] = 'CUX_Demo';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HAA_FF_Labels'] = 'HAA_FF_Labels';
$beanFiles['HAA_FF_Labels'] = 'modules/HAA_FF_Labels/HAA_FF_Labels.php';
$modules_exempt_from_availability_check['HAA_FF_Labels'] = 'HAA_FF_Labels';
$report_include_modules['HAA_FF_Labels'] = 'HAA_FF_Labels';
$modInvisList[] = 'HAA_FF_Labels';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HAA_FF'] = 'HAA_FF';
$beanFiles['HAA_FF'] = 'modules/HAA_FF/HAA_FF.php';
$moduleList[] = 'HAA_FF';
$beanList['HAA_FF_Conditions'] = 'HAA_FF_Conditions';
$beanFiles['HAA_FF_Conditions'] = 'modules/HAA_FF_Conditions/HAA_FF_Conditions.php';
$modules_exempt_from_availability_check['HAA_FF_Conditions'] = 'HAA_FF_Conditions';
$report_include_modules['HAA_FF_Conditions'] = 'HAA_FF_Conditions';
$modInvisList[] = 'HAA_FF_Conditions';
$beanList['HAA_FF_Fields'] = 'HAA_FF_Fields';
$beanFiles['HAA_FF_Fields'] = 'modules/HAA_FF_Fields/HAA_FF_Fields.php';
$modules_exempt_from_availability_check['HAA_FF_Fields'] = 'HAA_FF_Fields';
$report_include_modules['HAA_FF_Fields'] = 'HAA_FF_Fields';
$modInvisList[] = 'HAA_FF_Fields';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HAA_Maps'] = 'HAA_Maps';
$beanFiles['HAA_Maps'] = 'modules/HAA_Maps/HAA_Maps.php';
$moduleList[] = 'HAA_Maps';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HAA_Numbering_Rule'] = 'HAA_Numbering_Rule';
$beanFiles['HAA_Numbering_Rule'] = 'modules/HAA_Numbering_Rule/HAA_Numbering_Rule.php';
$moduleList[] = 'HAA_Numbering_Rule';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HAA_QUAL'] = 'HAA_QUAL';
$beanFiles['HAA_QUAL'] = 'modules/HAA_QUAL/HAA_QUAL.php';
$moduleList[] = 'HAA_QUAL';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HAA_UOM'] = 'HAA_UOM';
$beanFiles['HAA_UOM'] = 'modules/HAA_UOM/HAA_UOM.php';
$moduleList[] = 'HAA_UOM';
$beanList['HAA_UOM_Classes'] = 'HAA_UOM_Classes';
$beanFiles['HAA_UOM_Classes'] = 'modules/HAA_UOM_Classes/HAA_UOM_Classes.php';
$moduleList[] = 'HAA_UOM_Classes';
$beanList['HAA_UOM_Conversions'] = 'HAA_UOM_Conversions';
$beanFiles['HAA_UOM_Conversions'] = 'modules/HAA_UOM_Conversions/HAA_UOM_Conversions.php';
$moduleList[] = 'HAA_UOM_Conversions';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HAM_ACT'] = 'HAM_ACT';
$beanFiles['HAM_ACT'] = 'modules/HAM_ACT/HAM_ACT.php';
$moduleList[] = 'HAM_ACT';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HAM_ACT_OP'] = 'HAM_ACT_OP';
$beanFiles['HAM_ACT_OP'] = 'modules/HAM_ACT_OP/HAM_ACT_OP.php';
$moduleList[] = 'HAM_ACT_OP';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HAM_HAM_Subinv'] = 'HAM_HAM_Subinv';
$beanFiles['HAM_HAM_Subinv'] = 'modules/HAM_HAM_Subinv/HAM_HAM_Subinv.php';
$moduleList[] = 'HAM_HAM_Subinv';
$beanList['HAM_Maint_Sites'] = 'HAM_Maint_Sites';
$beanFiles['HAM_Maint_Sites'] = 'modules/HAM_Maint_Sites/HAM_Maint_Sites.php';
$moduleList[] = 'HAM_Maint_Sites';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HAM_Work_Centers'] = 'HAM_Work_Centers';
$beanFiles['HAM_Work_Centers'] = 'modules/HAM_Work_Centers/HAM_Work_Centers.php';
$moduleList[] = 'HAM_Work_Centers';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HAM_Work_Center_People'] = 'HAM_Work_Center_People';
$beanFiles['HAM_Work_Center_People'] = 'modules/HAM_Work_Center_People/HAM_Work_Center_People.php';
$moduleList[] = 'HAM_Work_Center_People';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HAM_Work_Center_Res'] = 'HAM_Work_Center_Res';
$beanFiles['HAM_Work_Center_Res'] = 'modules/HAM_Work_Center_Res/HAM_Work_Center_Res.php';
$moduleList[] = 'HAM_Work_Center_Res';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HAM_WO_Lines'] = 'HAM_WO_Lines';
$beanFiles['HAM_WO_Lines'] = 'modules/HAM_WO_Lines/HAM_WO_Lines.php';
$moduleList[] = 'HAM_WO_Lines';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HAM_WOOP'] = 'HAM_WOOP';
$beanFiles['HAM_WOOP'] = 'modules/HAM_WOOP/HAM_WOOP.php';
$moduleList[] = 'HAM_WOOP';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HAT_Assets'] = 'HAT_Assets';
$beanFiles['HAT_Assets'] = 'modules/HAT_Assets/HAT_Assets.php';
$moduleList[] = 'HAT_Assets';
$beanList['HAT_Asset_Locations'] = 'HAT_Asset_Locations';
$beanFiles['HAT_Asset_Locations'] = 'modules/HAT_Asset_Locations/HAT_Asset_Locations.php';
$moduleList[] = 'HAT_Asset_Locations';
$beanList['HAT_Asset_Trans'] = 'HAT_Asset_Trans';
$beanFiles['HAT_Asset_Trans'] = 'modules/HAT_Asset_Trans/HAT_Asset_Trans.php';
$moduleList[] = 'HAT_Asset_Trans';
$beanList['HAT_Asset_Trans_Batch'] = 'HAT_Asset_Trans_Batch';
$beanFiles['HAT_Asset_Trans_Batch'] = 'modules/HAT_Asset_Trans_Batch/HAT_Asset_Trans_Batch.php';
$moduleList[] = 'HAT_Asset_Trans_Batch';


 
 //WARNING: The contents of this file are auto-generated
$beanList['ABP_BPM_Actions'] = 'ABP_BPM_Actions';
$beanFiles['ABP_BPM_Actions'] = 'modules/ABP_BPM_Actions/ABP_BPM_Actions.php';
$moduleList[] = 'ABP_BPM_Actions';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HAM_Priority'] = 'HAM_Priority';
$beanFiles['HAM_Priority'] = 'modules/HAM_Priority/HAM_Priority.php';
$moduleList[] = 'HAM_Priority';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HAM_WO'] = 'HAM_WO';
$beanFiles['HAM_WO'] = 'modules/HAM_WO/HAM_WO.php';
$moduleList[] = 'HAM_WO';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HAM_SR'] = 'HAM_SR';
$beanFiles['HAM_SR'] = 'modules/HAM_SR/HAM_SR.php';
$moduleList[] = 'HAM_SR';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HAT_EventType'] = 'HAT_EventType';
$beanFiles['HAT_EventType'] = 'modules/HAT_EventType/HAT_EventType.php';
$moduleList[] = 'HAT_EventType';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HAT_Systems'] = 'HAT_Systems';
$beanFiles['HAT_Systems'] = 'modules/HAT_Systems/HAT_Systems.php';
$moduleList[] = 'HAT_Systems';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HAA_Codes'] = 'HAA_Codes';
$beanFiles['HAA_Codes'] = 'modules/HAA_Codes/HAA_Codes.php';
$moduleList[] = 'HAA_Codes';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HPR_AM_Catelog'] = 'HPR_AM_Catelog';
$beanFiles['HPR_AM_Catelog'] = 'modules/HPR_AM_Catelog/HPR_AM_Catelog.php';
$moduleList[] = 'HPR_AM_Catelog';
$beanList['HPR_AM_Roles'] = 'HPR_AM_Roles';
$beanFiles['HPR_AM_Roles'] = 'modules/HPR_AM_Roles/HPR_AM_Roles.php';
$moduleList[] = 'HPR_AM_Roles';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HAT_Counting_Batchs'] = 'HAT_Counting_Batchs';
$beanFiles['HAT_Counting_Batchs'] = 'modules/HAT_Counting_Batchs/HAT_Counting_Batchs.php';
$moduleList[] = 'HAT_Counting_Batchs';
$beanList['HAT_Counting_Lines'] = 'HAT_Counting_Lines';
$beanFiles['HAT_Counting_Lines'] = 'modules/HAT_Counting_Lines/HAT_Counting_Lines.php';
$moduleList[] = 'HAT_Counting_Lines';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HAT_Domains'] = 'HAT_Domains';
$beanFiles['HAT_Domains'] = 'modules/HAT_Domains/HAT_Domains.php';
$moduleList[] = 'HAT_Domains';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HAT_FA'] = 'HAT_FA';
$beanFiles['HAT_FA'] = 'modules/HAT_FA/HAT_FA.php';
$moduleList[] = 'HAT_FA';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HAT_Linear_Elements'] = 'HAT_Linear_Elements';
$beanFiles['HAT_Linear_Elements'] = 'modules/HAT_Linear_Elements/HAT_Linear_Elements.php';
$moduleList[] = 'HAT_Linear_Elements';
$beanList['HAT_Linear_Reference_Methods'] = 'HAT_Linear_Reference_Methods';
$beanFiles['HAT_Linear_Reference_Methods'] = 'modules/HAT_Linear_Reference_Methods/HAT_Linear_Reference_Methods.php';
$moduleList[] = 'HAT_Linear_Reference_Methods';
$beanList['HAT_Linear_Relationships'] = 'HAT_Linear_Relationships';
$beanFiles['HAT_Linear_Relationships'] = 'modules/HAT_Linear_Relationships/HAT_Linear_Relationships.php';
$moduleList[] = 'HAT_Linear_Relationships';
$beanList['HAT_Linear_Spec'] = 'HAT_Linear_Spec';
$beanFiles['HAT_Linear_Spec'] = 'modules/HAT_Linear_Spec/HAT_Linear_Spec.php';
$moduleList[] = 'HAT_Linear_Spec';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HAT_Meters'] = 'HAT_Meters';
$beanFiles['HAT_Meters'] = 'modules/HAT_Meters/HAT_Meters.php';
$moduleList[] = 'HAT_Meters';
/*$modules_exempt_from_availability_check['HAT_Meters'] = 'HAT_Meters';
$report_include_modules['HAT_Meters'] = 'HAT_Meters';
$modInvisList[] = 'HAT_Meters';
*/
 //WARNING: The contents of this file are auto-generated
$beanList['HAT_Meter_Types'] = 'HAT_Meter_Types';
$beanFiles['HAT_Meter_Types'] = 'modules/HAT_Meter_Types/HAT_Meter_Types.php';
$moduleList[] = 'HAT_Meter_Types';
/*$modules_exempt_from_availability_check['HAT_Meter_Types'] = 'HAT_Meter_Types';
$report_include_modules['HAT_Meter_Types'] = 'HAT_Meter_Types';
$modInvisList[] = 'HAT_Meter_Types';
*/
 //WARNING: The contents of this file are auto-generated
$beanList['HAT_Meter_Readings'] = 'HAT_Meter_Readings';
$beanFiles['HAT_Meter_Readings'] = 'modules/HAT_Meter_Readings/HAT_Meter_Readings.php';
$moduleList[] = 'HAT_Meter_Readings';
/*$modules_exempt_from_availability_check['HAT_Meter_Readings'] = 'HAT_Meter_Readings';
$report_include_modules['HAT_Meter_Readings'] = 'HAT_Meter_Readings';
$modInvisList[] = 'HAT_Meter_Readings';
*/

 
 //WARNING: The contents of this file are auto-generated
$beanList['HAT_Properties'] = 'HAT_Properties';
$beanFiles['HAT_Properties'] = 'modules/HAT_Properties/HAT_Properties.php';
$moduleList[] = 'HAT_Properties';
$beanList['HAT_Opn_Locations'] = 'HAT_Opn_Locations';
$beanFiles['HAT_Opn_Locations'] = 'modules/HAT_Opn_Locations/HAT_Opn_Locations.php';
$moduleList[] = 'HAT_Opn_Locations';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HAT_Asset_QUAL'] = 'HAT_Asset_QUAL';
$beanFiles['HAT_Asset_QUAL'] = 'modules/HAT_Asset_QUAL/HAT_Asset_QUAL.php';
$moduleList[] = 'HAT_Asset_QUAL';
$beanList['HAT_Asset_QUAL_Details'] = 'HAT_Asset_QUAL_Details';
$beanFiles['HAT_Asset_QUAL_Details'] = 'modules/HAT_Asset_QUAL_Details/HAT_Asset_QUAL_Details.php';
$moduleList[] = 'HAT_Asset_QUAL_Details';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HAT_Warranty_Types'] = 'HAT_Warranty_Types';
$beanFiles['HAT_Warranty_Types'] = 'modules/HAT_Warranty_Types/HAT_Warranty_Types.php';
$moduleList[] = 'HAT_Warranty_Types';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HIM_IM_Budget_Revisions'] = 'HIM_IM_Budget_Revisions';
$beanFiles['HIM_IM_Budget_Revisions'] = 'modules/HIM_IM_Budget_Revisions/HIM_IM_Budget_Revisions.php';
$moduleList[] = 'HIM_IM_Budget_Revisions';
$beanList['HIM_IM_Categories'] = 'HIM_IM_Categories';
$beanFiles['HIM_IM_Categories'] = 'modules/HIM_IM_Categories/HIM_IM_Categories.php';
$moduleList[] = 'HIM_IM_Categories';
$beanList['HIM_Programs'] = 'HIM_Programs';
$beanFiles['HIM_Programs'] = 'modules/HIM_Programs/HIM_Programs.php';
$moduleList[] = 'HIM_Programs';
$beanList['HIM_Project_Budgets'] = 'HIM_Project_Budgets';
$beanFiles['HIM_Project_Budgets'] = 'modules/HIM_Project_Budgets/HIM_Project_Budgets.php';
$moduleList[] = 'HIM_Project_Budgets';
$beanList['HIM_Project_Requests'] = 'HIM_Project_Requests';
$beanFiles['HIM_Project_Requests'] = 'modules/HIM_Project_Requests/HIM_Project_Requests.php';
$moduleList[] = 'HIM_Project_Requests';
$beanList['HIM_Project_Tasks'] = 'HIM_Project_Tasks';
$beanFiles['HIM_Project_Tasks'] = 'modules/HIM_Project_Tasks/HIM_Project_Tasks.php';
$moduleList[] = 'HIM_Project_Tasks';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HIT_IP'] = 'HIT_IP';
$beanFiles['HIT_IP'] = 'modules/HIT_IP/HIT_IP.php';
$moduleList[] = 'HIT_IP';
$beanList['HIT_IP_Allocations'] = 'HIT_IP_Allocations';
$beanFiles['HIT_IP_Allocations'] = 'modules/HIT_IP_Allocations/HIT_IP_Allocations.php';
$moduleList[] = 'HIT_IP_Allocations';
$beanList['HIT_VLAN'] = 'HIT_VLAN';
$beanFiles['HIT_VLAN'] = 'modules/HIT_VLAN/HIT_VLAN.php';
$moduleList[] = 'HIT_VLAN';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HIT_IP_Subnets'] = 'HIT_IP_Subnets';
$beanFiles['HIT_IP_Subnets'] = 'modules/HIT_IP_Subnets/HIT_IP_Subnets.php';
$moduleList[] = 'HIT_IP_Subnets';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HIT_Ports'] = 'HIT_Ports';
$beanFiles['HIT_Ports'] = 'modules/HIT_Ports/HIT_Ports.php';
$moduleList[] = 'HIT_Ports';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HIT_Racks'] = 'HIT_Racks';
$beanFiles['HIT_Racks'] = 'modules/HIT_Racks/HIT_Racks.php';
$moduleList[] = 'HIT_Racks';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HIT_Rack_Allocations'] = 'HIT_Rack_Allocations';
$beanFiles['HIT_Rack_Allocations'] = 'modules/HIT_Rack_Allocations/HIT_Rack_Allocations.php';
$moduleList[] = 'HIT_Rack_Allocations';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HMM_Locators'] = 'HMM_Locators';
$beanFiles['HMM_Locators'] = 'modules/HMM_Locators/HMM_Locators.php';
$moduleList[] = 'HMM_Locators';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HMM_MO_Requests'] = 'HMM_MO_Requests';
$beanFiles['HMM_MO_Requests'] = 'modules/HMM_MO_Requests/HMM_MO_Requests.php';
$moduleList[] = 'HMM_MO_Requests';
$beanList['HMM_MO_Request_Lines'] = 'HMM_MO_Request_Lines';
$beanFiles['HMM_MO_Request_Lines'] = 'modules/HMM_MO_Request_Lines/HMM_MO_Request_Lines.php';
$moduleList[] = 'HMM_MO_Request_Lines';
$beanList['HMM_Trans_Batch'] = 'HMM_Trans_Batch';
$beanFiles['HMM_Trans_Batch'] = 'modules/HMM_Trans_Batch/HMM_Trans_Batch.php';
$moduleList[] = 'HMM_Trans_Batch';
$beanList['HMM_Trans_Lines'] = 'HMM_Trans_Lines';
$beanFiles['HMM_Trans_Lines'] = 'modules/HMM_Trans_Lines/HMM_Trans_Lines.php';
$moduleList[] = 'HMM_Trans_Lines';


 
 //WARNING: The contents of this file are auto-generated
$beanList['HMM_Trans_History'] = 'HMM_Trans_History';
$beanFiles['HMM_Trans_History'] = 'modules/HMM_Trans_History/HMM_Trans_History.php';
$moduleList[] = 'HMM_Trans_History';


?>