<?php 
 //WARNING: The contents of this file are auto-generated

 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/aos_products_haa_uom_conversions_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/hat_assets_accountsMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/hat_assets_contactsMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/hat_assets_hat_asset_transMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/hat_asset_locations_hat_assetsMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/hat_asset_trans_batch_hat_asset_transMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/hat_counting_lines_hat_counting_batchsMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/hpr_am_roles_contactsMetaData.php');


?>