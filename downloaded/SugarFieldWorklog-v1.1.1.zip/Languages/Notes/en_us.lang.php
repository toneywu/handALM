<?php

$mod_strings['LBL_DISPLAY_IN_WORKLOG'] = "Display In Worklog?";
