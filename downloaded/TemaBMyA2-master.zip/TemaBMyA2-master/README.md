TemaBMyA2
=========

Theme for SuiteCRM

This theme has been contributed and rejected by SalesAgility team for not being upgrade-safe.

Since the theme is a good stuff I am opening it for converting it to "upgrade-safe"



