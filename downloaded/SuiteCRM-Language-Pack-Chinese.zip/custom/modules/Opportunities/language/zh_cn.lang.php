<?php
// created: 2014-01-29 16:47:08
$mod_strings = array (
  'TWITTER_USER_C' => 'Twitter用户',
);