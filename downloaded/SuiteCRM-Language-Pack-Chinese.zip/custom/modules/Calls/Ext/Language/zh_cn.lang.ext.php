<?php 
 //WARNING: The contents of this file are auto-generated



$mod_strings = array_merge($mod_strings,
	array(
		 'LBL_SECURITYGROUPS_SUBPANEL_TITLE' => "安全组",
	)
);



$mod_strings = array (
	'LBL_RESCHEDULE' => 'Reschedule',
    'LBL_RESCHEDULE_COUNT' => 'Call Attempts',
    'LBL_RESCHEDULE_DATE' => '日期',
    'LBL_RESCHEDULE_REASON' => '原因',
    'LBL_RESCHEDULE_ERROR1' => 'Please select a valid date',
    'LBL_RESCHEDULE_ERROR2' => 'Please select a reason',
    'LBL_RESCHEDULE_PANEL' => 'Reschedule',
    'LBL_RESCHEDULE_HISTORY' => 'Call Attempt History'

);

?>