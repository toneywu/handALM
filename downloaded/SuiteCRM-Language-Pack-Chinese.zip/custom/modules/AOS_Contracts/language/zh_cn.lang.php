<?php
// created: 2014-04-25 15:19:52
$mod_strings = array (
  'LBL_CONTACT' => '联系人',
);