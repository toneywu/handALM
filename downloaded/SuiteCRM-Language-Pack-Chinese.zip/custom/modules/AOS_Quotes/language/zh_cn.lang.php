<?php
// created: 2014-05-16 08:21:07
$mod_strings = array (
  'LBL_NAME' => '名称',
  'LBL_CREATED' => '创建人',
  'LBL_MODIFIED_NAME' => '修改者',
  'LBL_MODIFIED_USER' => '修改人',
  'LBL_ASSIGNED_TO_ID' => '负责用户',
  'LBL_ASSIGNED_TO_NAME' => '负责人',
  'LBL_CREATED_USER' => '创建人',
  'LBL_DATE_ENTERED' => '创建日期',
  'LBL_DATE_MODIFIED' => '修改日期',
  'LBL_DELETED' => '已删除',
  'LBL_DESCRIPTION' => '说明',
  'LBL_ID' => '编号',
  'LBL_MODIFIED' => '修改人',
  'LNK_NEW_RECORD' => '新建报价单',
  'LNK_LIST' => '查看报价单单',
  'MSG_SHOW_DUPLICATES' => '新建的客户信息可能会与已有的客户信息重复。您或者点击“保存”按钮，用已有的数据继续创建这条记录，或者点击“取消”按钮停止创建这条记录。',
  'LBL_LIST_FORM_TITLE' => '报价列表',
  'LBL_SEARCH_FORM_TITLE' => '查找报价单',
  'LBL_HOMEPAGE_TITLE' => '我的报价',
);