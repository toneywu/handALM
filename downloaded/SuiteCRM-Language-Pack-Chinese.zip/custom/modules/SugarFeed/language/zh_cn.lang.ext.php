<?php
// created: 2014-01-15 15:43:38
$mod_strings = array (
  'LBL_SOCIAL' => '社会的',
);