<?php
// created: 2014-05-06 08:26:54
$mod_strings = array (
  'LNK_NEW_RECORD' => '创建产品',
  'LNK_LIST' => '查看产品信息',
  'LBL_LIST_FORM_TITLE' => '产品信息列表',
  'LBL_SEARCH_FORM_TITLE' => '查找产品信息',
  'LBL_HOMEPAGE_TITLE' => '我的产品信息',
);