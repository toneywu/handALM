<?php
// created: 2014-04-30 08:54:19
$mod_strings = array (
  'LBL_RATING' => '评分:',
);