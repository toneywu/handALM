<?php

$mod_strings['LBL_JJWG_MAPS_ADMIN_HEADER'] = '谷歌地图';
$mod_strings['LBL_JJWG_MAPS_ADMIN_DESC'] = '管理您的地理编码，地理编码的测试，鉴于地理编码结果汇总，并配置高级设置.';
$mod_strings['LBL_JJWG_MAPS_ADMIN_CONFIG_TITLE'] = '谷歌地图设置';
$mod_strings['LBL_JJWG_MAPS_ADMIN_CONFIG_DESC'] = '配置设置来调整你的谷歌地图';
$mod_strings['LBL_JJWG_MAPS_ADMIN_GEOCODED_COUNTS_TITLE'] = '地理编码计数';
$mod_strings['LBL_JJWG_MAPS_ADMIN_GEOCODED_COUNTS_DESC'] = 'Shows the number of module objects geocoded, grouped by geocoding response.';
$mod_strings['LBL_JJWG_MAPS_ADMIN_DONATE_TITLE'] = '给这个项目捐款';
$mod_strings['LBL_JJWG_MAPS_ADMIN_DONATE_DESC'] = '请认真考虑给这个项目捐款!';
$mod_strings['LBL_JJWG_MAPS_ADMIN_GEOCODE_ADDRESSES_TITLE'] = '地理编码地址';
$mod_strings['LBL_JJWG_MAPS_ADMIN_GEOCODE_ADDRESSES_DESC'] = '将您的目标地址进行地理编码，这一过程可能需要几分钟的时间!';
$mod_strings['LBL_JJWG_MAPS_ADMIN_GEOCODING_TEST_TITLE'] = '地理编码测试';
$mod_strings['LBL_JJWG_MAPS_ADMIN_GEOCODING_TEST_DESC'] = '运行一个能显示详细结果的地理编码测试。';
$mod_strings['LBL_JJWG_MAPS_ADMIN_ADDRESS_CACHE_TITLE'] = '地址缓存';
$mod_strings['LBL_JJWG_MAPS_ADMIN_ADDRESS_CACHE_DESC'] = '提供了访问地址缓存信息的权限。这只是一个缓存。';
