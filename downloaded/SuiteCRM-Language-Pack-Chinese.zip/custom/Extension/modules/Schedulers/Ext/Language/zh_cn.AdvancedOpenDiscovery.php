<?php
$mod_strings['LBL_AODOPTIMISEINDEX'] = 'Optimise Advanced OpenDiscovery Index';
$mod_strings['LBL_AODINDEXUNINDEXED'] = 'Index unindexed documents';
