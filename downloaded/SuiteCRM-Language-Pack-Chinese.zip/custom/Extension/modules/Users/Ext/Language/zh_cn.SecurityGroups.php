<?php

$mod_strings = array_merge($mod_strings,
    array(
         'LBL_LIST_NONINHERITABLE' => "不可继承",
         'LBL_PRIMARY_GROUP' => "主要组",
    )
);
?>