<?php
/**
 * Social Feed Language Strings.
 */

$app_strings['FACEBOOK_USER_C'] = 'Facebook';
$app_strings['TWITTER_USER_C'] = 'Twitter';
$app_strings['LBL_FACEBOOK_USER_C'] = 'Facebook User';
$app_strings['LBL_TWITTER_USER_C'] = 'Twitter User';
$app_strings['LBL_PANEL_SOCIAL_FEED'] = 'Social Feed Details';