Simplified Chinese Language Pack for SuiteCRM 7.1.1 
====================================================

SuiteCRM是一款很优秀的开源CRM软件，与SugarCRM是一体的。具体可以看Wiki：http://en.wikipedia.org/wiki/SuiteCRM 和http://en.wikipedia.org/wiki/SugarCRM。

我本人很喜欢这款软件，但是从网上只有SugarCRM 6.5社区版的翻译，没有针对SuiteCRM的翻译。
为此，尝试做一个针对SuiteCRM的简体中文的翻译。
版本：SuiteCRM 7.1.1
有很多不足之处，请大家指正，谢谢。
本人联系方式：sqlserver2x@hotmail.com
              Chris Guo
              51387843 QQ

[langpack]: https://github.com/himingby/SuiteCRM-Language-Pack-Chinese
[suitecrm]: https://github.com/salesagility/SuiteCRM
