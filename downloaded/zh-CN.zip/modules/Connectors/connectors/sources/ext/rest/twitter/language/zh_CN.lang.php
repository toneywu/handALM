<?php

    if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

    $connector_strings = array (
        //Vardef labels
        'LBL_LICENSING_INFO' => '<table border="0" cellspacing="1"><tr><th valign="top" width="35%" class="dataLabel">Twitter 应用程序信息 </th></tr>
<tr><td width="35%" class="dataLabel">您将需要创建一个 Twitter 的开发人员帐户 <a href=https://dev.twitter.com/> 注册</a></td></tr></table>',
        //Configuration labels
        'consumer_key' => '消费者key',
        'consumer_secret' => '消费者Secret',
    );


?>
