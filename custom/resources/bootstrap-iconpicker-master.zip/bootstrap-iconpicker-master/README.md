

# [Bootstrap-Iconpicker v1.6.0](http://victor-valencia.github.io/bootstrap-iconpicker)
![Iconpicker](bootstrap-iconpicker.png)

This is a fork of the above original Icon Picker. This fork will be removed in the future and all access should be through the original GitHub repository.
