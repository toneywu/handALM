1.1.0
------

* `isIp()` and `isDecimalIp()` functions
* Added tests
* Added `.editorconfig`, `.eslintrc`, and `.jshintrc` files
* `calculate()`, `calculateSubnetMask()`, and `calculateCIDRPrefix()` now accept IPs in string and number format


1.0.0
-----

Initial release
